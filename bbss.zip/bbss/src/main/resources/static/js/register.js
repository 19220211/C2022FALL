// 显示消息的通用函数
function showMessage(message, isError = false) {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.innerHTML = message;
        messageDiv.className = isError ? 'error-message' : 'success-message';
        messageDiv.style.display = 'block';
    }
}

// 注册函数
async function register() {
    const username = document.getElementById('registerUsername').value.trim();
    const password = document.getElementById('registerPassword').value.trim();
    const confirmPassword = document.getElementById('confirmPassword').value.trim();
    const nickname = document.getElementById('nickname').value.trim();

    // 调试信息
    console.log('注册信息：', {
        username,
        password: '***',
        confirmPassword: '***',
        nickname
    });

    if (!username || !password || !confirmPassword || !nickname) {
        showMessage('请填写所有字段', true);
        return;
    }

    if (password !== confirmPassword) {
        showMessage('两次输入的密码不一致', true);
        return;
    }

    const userData = {
        username: username,
        password: password,
        nickname: nickname,
        email: `${username}@example.com`
    };

    try {
        console.log('发送的数据：', {...userData, password: '***'});

        const response = await fetch('http://localhost:8081/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify(userData)
        });

        let data;
        const responseText = await response.text();
        console.log('服务器响应：', responseText);
        
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            console.error('解析响应数据失败：', e);
            throw new Error('服务器响应格式错误');
        }
        
        if (!response.ok) {
            throw new Error(data.message || '注册失败');
        }

        if (data.success) {
            showMessage('注册成功，即将跳转到登录页面');
            // 注册成功后2秒跳转到登录页面
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            showMessage(data.message || '注册失败', true);
        }
    } catch (error) {
        console.error('Registration error:', error);
        showMessage(error.message || '注册失败，请稍后重试', true);
    }
}

// 页面加载完成后添加回车键提交功能
document.addEventListener('DOMContentLoaded', function() {
    // 为表单添加提交事件
    const form = document.querySelector('.container');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            register();
        });
    }

    // 添加回车键提交
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            register();
        }
    });
}); 