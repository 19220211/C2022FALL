// 显示消息的通用函数
function showMessage(message, isError = false) {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.textContent = message;
        messageDiv.className = `message ${isError ? 'error' : 'success'}`;
        messageDiv.style.display = 'block';

        setTimeout(() => {
            messageDiv.style.display = 'none';
        }, 3000);
    }
}

// 登录函数
async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (!username || !password) {
        showMessage('用户名和密码不能为空', true);
        return;
    }

    try {
        const response = await fetch('http://localhost:8081/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({
                username,
                password
            })
        });

        const data = await response.json();

        if (response.ok && data.success) {
            showMessage('登录成功');
            // 检查用户角色
            if (data.user && data.user.role === 'ADMIN') {
                setTimeout(() => {
                    window.location.href = 'admin.html';
                }, 1000);
            } else {
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            }
        } else {
            showMessage(data.message || '登录失败', true);
        }
    } catch (error) {
        console.error('Error during login:', error);
        showMessage('登录失败，请稍后重试', true);
    }
}

// 页面加载完成后添加回车键提交功能
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const messageDiv = document.getElementById('message');
    const baseUrl = 'http://localhost:8081';

    // 检查是否有错误消息参数
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('error') && urlParams.get('error') !== 'unauthorized') {
        showMessage('登录失败，请检查用户名和密码', true);
    }
    if (urlParams.has('expired')) {
        showMessage('会话已过期，请重新登录', true);
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (!username || !password) {
                showMessage('用户名和密码不能为空', true);
                return;
            }

            try {
                const response = await fetch('http://localhost:8081/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username,
                        password
                    })
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    showMessage('登录成功');
                    // 检查用户角色
                    if (data.user && data.user.role === 'ADMIN') {
                        setTimeout(() => {
                            window.location.href = 'admin.html';
                        }, 1000);
                    } else {
                        setTimeout(() => {
                            window.location.href = 'index.html';
                        }, 1000);
                    }
                } else {
                    showMessage(data.message || '登录失败', true);
                }
            } catch (error) {
                console.error('Error during login:', error);
                showMessage('登录失败，请稍后重试', true);
            }
        });
    }
});