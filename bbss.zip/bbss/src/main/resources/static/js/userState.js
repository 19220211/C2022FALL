// 用户状态管理工具类
const UserState = {
    baseUrl: 'http://localhost:8081',

    // 获取当前登录用户信息
    async getCurrentUser() {
        try {
            const response = await fetch(`${this.baseUrl}/api/auth/status`, {
                credentials: 'include'
            });
            const data = await response.json();
            return data.loggedIn ? data.user : null;
        } catch (error) {
            console.error('Error getting current user:', error);
            return null;
        }
    },

    // 更新页面顶部的用户信息
    async updateUserInfo() {
        const userInfoElement = document.getElementById('userInfo');
        if (!userInfoElement) return;

        const user = await this.getCurrentUser();
        if (user) {
            userInfoElement.innerHTML = `
                <span class="user-info">
                    <span class="username">${user.nickname || user.username}</span>
                    <a href="profile.html">个人中心</a>
                    <a href="javascript:void(0)" onclick="UserState.logout()">退出</a>
                </span>
            `;
        } else {
            userInfoElement.innerHTML = `
                <a href="login.html" class="btn btn-primary">登录</a>
                <a href="register.html" class="btn btn-outline">注册</a>
            `;
        }
    },

    // 退出登录
    async logout() {
        try {
            const response = await fetch(`${this.baseUrl}/api/auth/logout`, {
                method: 'POST',
                credentials: 'include'
            });

            if (response.ok) {
                // 清除sessionStorage中的用户信息
                sessionStorage.removeItem('user');
                // 跳转到登录页面
                window.location.href = 'login.html';
            } else {
                console.error('Logout failed');
            }
        } catch (error) {
            console.error('Error during logout:', error);
        }
    },

    // 检查登录状态
    async checkLoginStatus() {
        const user = await this.getCurrentUser();
        if (!user) {
            const currentPath = window.location.pathname.toLowerCase();
            const publicPaths = ['/', '/index.html', '/login.html', '/register.html'];
            if (!publicPaths.includes(currentPath)) {
                window.location.href = 'login.html';
                return false;
            }
        }
        await this.updateUserInfo();
        return true;
    }
};

// 页面加载时检查登录状态
document.addEventListener('DOMContentLoaded', () => {
    UserState.checkLoginStatus();
}); 