// 获取所有帖子
async function fetchPosts() {
    try {
        const response = await fetch('http://localhost:8081/api/posts', {
            credentials: 'include'
        });
        const data = await response.json();
        displayPosts(data);
    } catch (error) {
        console.error('Error fetching posts:', error);
        showError('获取帖子失败，请稍后重试');
    }
}

// 显示帖子列表
function displayPosts(posts) {
    const postsContainer = document.getElementById('postsContainer');
    if (!posts || posts.length === 0) {
        postsContainer.innerHTML = '<div class="post-item">暂无帖子</div>';
        return;
    }

    postsContainer.innerHTML = posts.map(post => `
        <div class="post-item">
            <div class="post-header">
                <h3 class="post-title">${post.title}</h3>
                <div class="post-meta">
                    <span>${post.author}</span>
                    <span>·</span>
                    <span>${formatDate(post.createTime)}</span>
                </div>
            </div>
            <div class="post-content">
                ${post.content}
            </div>
            <div class="post-footer">
                <div class="post-actions">
                    <a href="#" class="post-action" onclick="likePost(${post.id})">
                        <i class="fas fa-thumbs-up"></i>
                        <span>${post.likes || 0}</span>
                    </a>
                    <a href="#" class="post-action" onclick="showComments(${post.id})">
                        <i class="fas fa-comment"></i>
                        <span>${post.comments || 0}</span>
                    </a>
                </div>
            </div>
        </div>
    `).join('');
}

// 格式化日期
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// 显示错误信息
function showError(message) {
    const postsContainer = document.getElementById('postsContainer');
    postsContainer.innerHTML = `
        <div class="post-item" style="color: red; text-align: center;">
            ${message}
        </div>
    `;
}

// 导航栏激活状态
function setActiveNav(linkId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.getElementById(linkId).classList.add('active');
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    const postsList = document.getElementById('postsList');
    const categoryFilter = document.getElementById('categoryFilter');
    const userInfo = document.getElementById('userInfo');
    const baseUrl = 'http://localhost:8081';

    let currentUser = null;

    // 检查登录状态
    checkLoginStatus();

    // 加载帖子
    loadPosts();

    // 分类过滤
    categoryFilter.addEventListener('change', loadPosts);

    // 检查登录状态
    async function checkLoginStatus() {
        try {
            const response = await fetch(`${baseUrl}/api/auth/status`, {
                credentials: 'include'
            });
            const data = await response.json();
            
            if (data.loggedIn) {
                currentUser = data.user;
                updateUserInfo(currentUser);
            } else {
                showLoginButton();
            }
        } catch (error) {
            console.error('Error checking login status:', error);
            showLoginButton();
        }
    }

    function updateUserInfo(user) {
        userInfo.innerHTML = `
            <span class="user-info">
                <span class="username">${user.nickname}</span>
                <a href="profile.html">个人中心</a>
                <a href="#" onclick="logout()">退出</a>
            </span>
        `;
    }

    function showLoginButton() {
        userInfo.innerHTML = `
            <a href="login.html" class="btn btn-primary">登录</a>
            <a href="register.html" class="btn btn-outline">注册</a>
        `;
    }

    // 加载帖子列表
    async function loadPosts() {
        try {
            const category = categoryFilter.value;
            const url = category 
                ? `${baseUrl}/api/posts?category=${encodeURIComponent(category)}`
                : `${baseUrl}/api/posts`;
            
            const response = await fetch(url, {
                credentials: 'include'
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }
            
            // 如果返回的是错误消息格式
            if (data.success === false) {
                throw new Error(data.message || '加载帖子失败');
            }
            
            // 确保data是数组
            const posts = Array.isArray(data) ? data : [];
            displayPosts(posts);
        } catch (error) {
            console.error('Error loading posts:', error);
            postsList.innerHTML = `<div class="error-message">加载帖子失败：${error.message}</div>`;
        }
    }

    // 显示帖子列表
    function displayPosts(posts) {
        if (!Array.isArray(posts)) {
            console.error('Expected array of posts but got:', posts);
            postsList.innerHTML = '<div class="error-message">数据格式错误</div>';
            return;
        }

        postsList.innerHTML = '';
        
        if (posts.length === 0) {
            postsList.innerHTML = '<div class="no-posts">暂无帖子</div>';
            return;
        }
        
        posts.forEach(post => {
            try {
                const postElement = createPostElement(post);
                postsList.appendChild(postElement);
            } catch (error) {
                console.error('Error creating post element:', error, post);
            }
        });
    }

    // 创建帖子元素
    function createPostElement(post) {
        if (!post || !post.user) {
            console.error('Invalid post data:', post);
            return null;
        }

        const postDiv = document.createElement('div');
        postDiv.className = 'post-item';
        
        const isAuthor = currentUser && currentUser.id === post.user.id;
        
        try {
            postDiv.innerHTML = `
                <div class="post-header">
                    <h3 class="post-title">${escapeHtml(post.title || '')}</h3>
                    <div class="post-meta">
                        <span class="post-category">${escapeHtml(post.category || '')}</span>
                        <span>${formatDate(post.createTime)}</span>
                    </div>
                </div>
                <div class="post-content">${escapeHtml(post.content || '')}</div>
                <div class="post-footer">
                    <div class="post-author">
                        <span>${escapeHtml(post.user.nickname || '')}</span>
                    </div>
                    <div class="post-actions">
                        <button class="action-btn like-btn" data-post-id="${post.id}">
                            <i class="fas fa-thumbs-up"></i>
                            <span>${post.likes || 0}</span>
                        </button>
                        <button class="action-btn comment-btn" data-post-id="${post.id}">
                            <i class="fas fa-comment"></i>
                            <span>${post.comments || 0}</span>
                        </button>
                        ${isAuthor ? `
                            <button class="action-btn edit-btn" data-post-id="${post.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete-btn" data-post-id="${post.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </div>
                <div class="comment-section" style="display: none;">
                    <div class="comments-list"></div>
                    <div class="comment-form">
                        <textarea class="comment-input" placeholder="写下你的评论..."></textarea>
                        <button class="comment-submit">发表评论</button>
                    </div>
                </div>
            `;

            // 添加事件监听器
            const likeBtn = postDiv.querySelector('.like-btn');
            const commentBtn = postDiv.querySelector('.comment-btn');
            const commentSection = postDiv.querySelector('.comment-section');
            const commentSubmit = postDiv.querySelector('.comment-submit');
            const commentInput = postDiv.querySelector('.comment-input');
            
            if (likeBtn) {
                likeBtn.addEventListener('click', () => handleLike(post.id));
            }
            
            if (commentBtn) {
                commentBtn.addEventListener('click', () => {
                    toggleCommentSection(commentSection, post.id);
                });
            }

            if (commentSubmit && commentInput) {
                commentSubmit.addEventListener('click', () => {
                    handleComment(post.id, commentInput);
                });
            }

            if (isAuthor) {
                const editBtn = postDiv.querySelector('.edit-btn');
                const deleteBtn = postDiv.querySelector('.delete-btn');
                
                if (editBtn) {
                    editBtn.addEventListener('click', () => handleEdit(post.id));
                }
                if (deleteBtn) {
                    deleteBtn.addEventListener('click', () => handleDelete(post.id));
                }
            }

            return postDiv;
        } catch (error) {
            console.error('Error creating post element:', error, post);
            return null;
        }
    }

    // 处理点赞
    async function handleLike(postId) {
        if (!currentUser) {
            alert('请先登录');
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/posts/${postId}/like`, {
                method: 'POST',
                credentials: 'include'
            });

            if (!response.ok) {
                const data = await response.json();
                alert(data.message || '点赞失败，请稍后重试');
                return;
            }

            loadPosts(); // 重新加载帖子列表
        } catch (error) {
            console.error('Error liking post:', error);
            alert('点赞失败，请稍后重试');
        }
    }

    // 切换评论区显示
    async function toggleCommentSection(commentSection, postId) {
        if (!currentUser) {
            alert('请先登录');
            return;
        }

        if (commentSection.style.display === 'none') {
            commentSection.style.display = 'block';
            await loadComments(postId, commentSection.querySelector('.comments-list'));
        } else {
            commentSection.style.display = 'none';
        }
    }

    // 加载评论列表
    async function loadComments(postId, commentsContainer) {
        try {
            const response = await fetch(`${baseUrl}/api/posts/${postId}/comments`, {
                credentials: 'include'
            });

            if (!response.ok) {
                throw new Error('加载评论失败');
            }

            const comments = await response.json();
            
            if (!Array.isArray(comments) || comments.length === 0) {
                commentsContainer.innerHTML = '<div class="no-comments">暂无评论</div>';
                return;
            }

            commentsContainer.innerHTML = comments.map(comment => `
                <div class="comment-item">
                    <div class="comment-header">
                        <span class="comment-author">${escapeHtml(comment.user.nickname)}</span>
                        <span class="comment-time">${formatDate(comment.createTime)}</span>
                    </div>
                    <div class="comment-content">${escapeHtml(comment.content)}</div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading comments:', error);
            commentsContainer.innerHTML = '<div class="error-message">加载评论失败，请稍后重试</div>';
        }
    }

    // 处理评论提交
    async function handleComment(postId, commentInput) {
        if (!currentUser) {
            alert('请先登录');
            return;
        }

        const content = commentInput.value.trim();
        if (!content) {
            alert('请输入评论内容');
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/posts/${postId}/comment`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({ content })
            });

            if (!response.ok) {
                const data = await response.json();
                throw new Error(data.message || '评论失败，请稍后重试');
            }

            commentInput.value = '';
            // 重新加载评论列表
            const commentSection = commentInput.closest('.comment-section');
            await loadComments(postId, commentSection.querySelector('.comments-list'));
        } catch (error) {
            console.error('Error commenting post:', error);
            alert(error.message || '评论失败，请稍后重试');
        }
    }

    // 处理编辑
    function handleEdit(postId) {
        window.location.href = `post.html?edit=${postId}`;
    }

    // 处理删除
    async function handleDelete(postId) {
        if (confirm('确定要删除这篇帖子吗？')) {
            try {
                const response = await fetch(`${baseUrl}/api/posts/${postId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                
                if (!response.ok) {
                    const data = await response.json();
                    alert(data.message || '删除失败，请稍后重试');
                    return;
                }

                loadPosts(); // 重新加载帖子列表
            } catch (error) {
                console.error('Error deleting post:', error);
                alert('删除失败，请稍后重试');
            }
        }
    }

    // 工具函数：HTML转义
    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    // 工具函数：格式化日期
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // 最高机密功能
    const secretBtn = document.getElementById('secretBtn');
    const secretModal = document.getElementById('secretModal');
    const closeBtn = document.querySelector('.close');

    // 点击最高机密按钮
    secretBtn.addEventListener('click', function() {
        secretModal.style.display = 'block';
    });

    // 点击关闭按钮
    closeBtn.addEventListener('click', function() {
        secretModal.style.display = 'none';
    });

    // 点击模态框外部关闭
    window.addEventListener('click', function(event) {
        if (event.target == secretModal) {
            secretModal.style.display = 'none';
        }
    });
});

// 验证密钥
async function checkSecretKey() {
    const secretKey = document.getElementById('secretKey').value;
    const correctKey = 'bbss2024'; // 这里设置正确的密钥

    if (secretKey === correctKey) {
        try {
            const response = await fetch('http://localhost:8081/api/auth/admin-access', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({ secretKey })
            });

            if (response.ok) {
                window.location.href = 'admin.html';
            } else {
                showMessage('访问被拒绝', true);
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage('系统错误，请稍后重试', true);
        }
    } else {
        showMessage('密钥错误', true);
    }
}

// 显示消息
function showMessage(message, isError = false) {
    const messageDiv = document.getElementById('message');
    if (!messageDiv) {
        const div = document.createElement('div');
        div.id = 'message';
        document.body.appendChild(div);
    }
    
    const msg = document.getElementById('message');
    msg.textContent = message;
    msg.className = `message ${isError ? 'error' : 'success'}`;
    msg.style.display = 'block';

    setTimeout(() => {
        msg.style.display = 'none';
    }, 3000);
} 