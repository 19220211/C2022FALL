const baseUrl = 'http://localhost:8081';

document.addEventListener('DOMContentLoaded', function() {
    loadPosts();
    loadComments();
    loadCategories();
});

// 加载帖子列表
async function loadPosts() {
    const postsContainer = document.getElementById('postsList');
    if (!postsContainer) return;

    postsContainer.innerHTML = '<div class="loading">加载中...</div>';

    try {
        const response = await fetch(`${baseUrl}/api/posts`, {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取帖子失败');
        }

        const posts = await response.json();
        displayPosts(posts);
    } catch (error) {
        console.error('Error loading posts:', error);
        postsContainer.innerHTML = '<div class="error">加载帖子失败</div>';
    }
}

// 加载评论列表
async function loadComments() {
    const commentsContainer = document.getElementById('commentsList');
    if (!commentsContainer) return;

    commentsContainer.innerHTML = '<div class="loading">加载中...</div>';

    try {
        const response = await fetch(`${baseUrl}/api/admin/comments`, {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取评论失败');
        }

        const comments = await response.json();
        displayComments(comments);
    } catch (error) {
        console.error('Error loading comments:', error);
        commentsContainer.innerHTML = '<div class="error">加载评论失败</div>';
    }
}

// 加载分类列表
async function loadCategories() {
    const categoriesContainer = document.getElementById('categoriesList');
    if (!categoriesContainer) return;

    categoriesContainer.innerHTML = '<div class="loading">加载中...</div>';

    try {
        const response = await fetch(`${baseUrl}/api/admin/categories`, {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取分类失败');
        }

        const categories = await response.json();
        displayCategories(categories);
    } catch (error) {
        console.error('Error loading categories:', error);
        categoriesContainer.innerHTML = '<div class="error">加载分类失败</div>';
    }
}

// 显示帖子列表
function displayPosts(posts) {
    const postsContainer = document.getElementById('postsList');
    if (!posts || posts.length === 0) {
        postsContainer.innerHTML = '<div class="empty">暂无帖子</div>';
        return;
    }

    postsContainer.innerHTML = posts.map(post => `
        <div class="list-item">
            <div class="content">
                <h3>${post.title}</h3>
                <p>作者：${post.user.nickname} | 分类：${post.category} | 时间：${formatDate(post.createTime)}</p>
            </div>
            <button onclick="deletePost(${post.id})" class="delete-btn">删除</button>
        </div>
    `).join('');
}

// 显示评论列表
function displayComments(comments) {
    const commentsContainer = document.getElementById('commentsList');
    if (!comments || comments.length === 0) {
        commentsContainer.innerHTML = '<div class="empty">暂无评论</div>';
        return;
    }

    commentsContainer.innerHTML = comments.map(comment => `
        <div class="list-item">
            <div class="content">
                <p>${comment.content}</p>
                <p>作者：${comment.user.nickname} | 时间：${formatDate(comment.createTime)}</p>
            </div>
            <button onclick="deleteComment(${comment.id})" class="delete-btn">删除</button>
        </div>
    `).join('');
}

// 显示分类列表
function displayCategories(categories) {
    const categoriesContainer = document.getElementById('categoriesList');
    if (!categories || categories.length === 0) {
        categoriesContainer.innerHTML = '<div class="empty">暂无分类</div>';
        return;
    }

    categoriesContainer.innerHTML = categories.map(category => `
        <div class="list-item">
            <div class="content">
                <span>${category.name}</span>
                <span>帖子数：${category.postCount || 0}</span>
            </div>
            <button onclick="deleteCategory('${category.name}')" class="delete-btn">删除</button>
        </div>
    `).join('');
}

// 添加分类
async function addCategory() {
    const categoryName = document.getElementById('categoryName').value.trim();
    if (!categoryName) {
        alert('请输入分类名称');
        return;
    }

    try {
        const response = await fetch(`${baseUrl}/api/admin/categories`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ name: categoryName })
        });

        if (response.ok) {
            alert('分类添加成功');
            document.getElementById('categoryName').value = '';
            loadCategories();
        } else {
            alert('添加分类失败');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('添加分类失败');
    }
}

// 删除帖子
async function deletePost(postId) {
    if (!confirm('确定要删除这篇帖子吗？')) return;

    try {
        const response = await fetch(`${baseUrl}/api/admin/posts/${postId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (response.ok) {
            alert('删除成功');
            loadPosts();
        } else {
            alert('删除失败');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('删除失败');
    }
}

// 删除评论
async function deleteComment(commentId) {
    if (!confirm('确定要删除这条评论吗？')) return;

    try {
        const response = await fetch(`${baseUrl}/api/admin/comments/${commentId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (response.ok) {
            alert('删除成功');
            loadComments();
        } else {
            alert('删除失败');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('删除失败');
    }
}

// 删除分类
async function deleteCategory(categoryName) {
    if (!confirm(`确定要删除分类"${categoryName}"吗？`)) return;

    try {
        const response = await fetch(`${baseUrl}/api/admin/categories/${encodeURIComponent(categoryName)}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (response.ok) {
            alert('删除成功');
            loadCategories();
        } else {
            alert('删除失败');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('删除失败');
    }
}

// 格式化日期
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}