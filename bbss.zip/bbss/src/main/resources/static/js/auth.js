document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const messageDiv = document.getElementById('message');
    const baseUrl = 'http://localhost:8081';

    // 检查是否有错误消息参数
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('error') && urlParams.get('error') !== 'unauthorized') {
        showMessage('登录失败，请检查用户名和密码', true);
    }
    if (urlParams.has('expired')) {
        showMessage('会话已过期，请重新登录', true);
    }

    // 只在非登录页面检查登录状态
    const currentPath = window.location.pathname.toLowerCase();
    if (currentPath !== '/login.html' && currentPath !== '/register.html') {
        checkLoginStatus();
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch(`${baseUrl}/api/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include',
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();
                
                if (response.ok && data.success) {
                    // 保存用户信息到 sessionStorage
                    sessionStorage.setItem('user', JSON.stringify(data.user));
                    showMessage('登录成功，正在跳转...', false);
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 1000);
                } else {
                    showMessage(data.message || '登录失败，请重试', true);
                }
            } catch (error) {
                console.error('Error during login:', error);
                showMessage('登录失败，请稍后重试', true);
            }
        });
    }

    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const nickname = document.getElementById('nickname').value;

            if (password !== confirmPassword) {
                showMessage('两次输入的密码不一致', true);
                return;
            }

            try {
                const response = await fetch(`${baseUrl}/api/auth/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username,
                        password,
                        nickname
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    showMessage('注册成功，请登录', false);
                    setTimeout(() => {
                        window.location.href = `${baseUrl}/login.html`;
                    }, 1500);
                } else {
                    showMessage(data.message || '注册失败，请重试', true);
                }
            } catch (error) {
                console.error('Error during registration:', error);
                showMessage('注册失败，请稍后重试', true);
            }
        });
    }

    function showMessage(message, isError = false) {
        if (messageDiv) {
            messageDiv.textContent = message;
            messageDiv.className = 'message ' + (isError ? 'error' : 'success');
            messageDiv.style.display = 'block';
        }
    }
});

// 检查登录状态
async function checkLoginStatus() {
    const baseUrl = 'http://localhost:8081';
    try {
        // 首先检查 sessionStorage
        const storedUser = sessionStorage.getItem('user');
        if (storedUser) {
            return JSON.parse(storedUser);
        }

        // 如果 sessionStorage 中没有，则请求服务器
        const response = await fetch(`${baseUrl}/api/auth/status`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('未登录');
        }

        const data = await response.json();
        if (!data.loggedIn) {
            throw new Error('未登录');
        }

        // 保存用户信息到 sessionStorage
        sessionStorage.setItem('user', JSON.stringify(data.user));
        return data.user;
    } catch (error) {
        console.error('登录状态检查失败:', error);
        // 仅在非公共页面时重定向
        const currentPath = window.location.pathname.toLowerCase();
        const publicPaths = ['/', '/index.html', '/login.html', '/register.html'];
        if (!publicPaths.includes(currentPath)) {
            window.location.href = 'login.html';
        }
        return null;
    }
}

// 退出登录
async function logout() {
    const baseUrl = 'http://localhost:8081';
    try {
        const response = await fetch(`${baseUrl}/api/auth/logout`, {
            method: 'POST',
            credentials: 'include'
        });

        if (response.ok) {
            // 清除 sessionStorage
            sessionStorage.removeItem('user');
            window.location.href = 'login.html';
        } else {
            console.error('退出登录失败');
        }
    } catch (error) {
        console.error('退出登录失败:', error);
    }
}

// 获取当前用户信息
function getCurrentUser() {
    const userStr = sessionStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

// 导出函数
window.checkLoginStatus = checkLoginStatus;
window.logout = logout;
window.getCurrentUser = getCurrentUser; 