// 页面加载时检查登录状态并加载用户信息
document.addEventListener('DOMContentLoaded', async function() {
    const baseUrl = 'http://localhost:8081';

    // 检查登录状态
    const user = await UserState.getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    // 加载用户信息
    loadUserInfo();

    // 加载用户的帖子和评论
    loadUserPosts();
    loadUserComments();

    // 设置密码表单提交事件
    const passwordForm = document.getElementById('passwordForm');
    passwordForm.addEventListener('submit', handlePasswordUpdate);
});

// 加载用户信息
async function loadUserInfo() {
    try {
        const response = await fetch('http://localhost:8081/api/profile', {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取用户信息失败');
        }

        const user = await response.json();
        document.getElementById('username').textContent = user.username;
        document.getElementById('nickname').textContent = user.nickname || '未设置';
    } catch (error) {
        console.error('Error loading user info:', error);
        showMessage('加载用户信息失败', true);
    }
}

// 加载用户的帖子
async function loadUserPosts() {
    const postsContainer = document.getElementById('myPosts');
    postsContainer.innerHTML = '<div class="loading">加载中</div>';

    try {
        const response = await fetch('http://localhost:8081/api/profile/posts', {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取帖子失败');
        }

        const posts = await response.json();
        
        if (posts.length === 0) {
            postsContainer.innerHTML = '<div class="empty-message">还没有发布过帖子</div>';
            return;
        }

        postsContainer.innerHTML = posts.map(post => `
            <div class="post-item" data-id="${post.id}">
                <div class="post-header">
                    <h3 class="post-title">${escapeHtml(post.title)}</h3>
                    <div class="post-meta">
                        <span>${formatDate(post.createTime)}</span>
                        <span>评论 ${post.comments}</span>
                        <span>点赞 ${post.likes}</span>
                    </div>
                </div>
                <div class="post-content">${escapeHtml(post.content)}</div>
                <div class="post-actions">
                    <button class="action-btn delete-btn" onclick="deletePost(${post.id})">
                        <i class="fas fa-trash"></i> 删除
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading posts:', error);
        postsContainer.innerHTML = '<div class="empty-message">加载帖子失败</div>';
    }
}

// 加载用户的评论
async function loadUserComments() {
    const commentsContainer = document.getElementById('myComments');
    commentsContainer.innerHTML = '<div class="loading">加载中</div>';

    try {
        const response = await fetch('http://localhost:8081/api/profile/comments', {
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('获取评论失败');
        }

        const comments = await response.json();
        
        if (comments.length === 0) {
            commentsContainer.innerHTML = '<div class="empty-message">还没有发表过评论</div>';
            return;
        }

        commentsContainer.innerHTML = comments.map(comment => `
            <div class="comment-item" data-id="${comment.id}">
                <div class="comment-header">
                    <div class="comment-post-title">
                        评论于：<a href="post.html?id=${comment.post.id}">${escapeHtml(comment.post.title)}</a>
                    </div>
                    <div class="comment-meta">
                        ${formatDate(comment.createTime)}
                    </div>
                </div>
                <div class="comment-content">${escapeHtml(comment.content)}</div>
                <div class="comment-actions">
                    <button class="action-btn delete-btn" onclick="deleteComment(${comment.id})">
                        <i class="fas fa-trash"></i> 删除
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading comments:', error);
        commentsContainer.innerHTML = '<div class="empty-message">加载评论失败</div>';
    }
}

// 删除帖子
async function deletePost(postId) {
    if (!confirm('确定要删除这篇帖子吗？')) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:8081/api/posts/${postId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('删除帖子失败');
        }

        showMessage('帖子已删除');
        loadUserPosts(); // 重新加载帖子列表
    } catch (error) {
        console.error('Error deleting post:', error);
        showMessage('删除帖子失败', true);
    }
}

// 删除评论
async function deleteComment(commentId) {
    if (!confirm('确定要删除这条评论吗？')) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:8081/api/profile/comments/${commentId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('删除评论失败');
        }

        showMessage('评论已删除');
        loadUserComments(); // 重新加载评论列表
    } catch (error) {
        console.error('Error deleting comment:', error);
        showMessage('删除评论失败', true);
    }
}

// 工具函数：HTML转义
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// 工具函数：格式化日期
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// 显示修改昵称表单
function showEditNickname() {
    const editForm = document.getElementById('editNicknameForm');
    const nicknameInput = document.getElementById('newNickname');
    const currentNickname = document.getElementById('nickname').textContent;
    
    editForm.classList.add('active');
    nicknameInput.value = currentNickname === '未设置' ? '' : currentNickname;
    nicknameInput.focus();
}

// 隐藏修改昵称表单
function hideEditNickname() {
    const editForm = document.getElementById('editNicknameForm');
    editForm.classList.remove('active');
}

// 更新昵称
async function updateNickname() {
    const newNickname = document.getElementById('newNickname').value.trim();
    
    if (!newNickname) {
        showMessage('昵称不能为空', true);
        return;
    }

    try {
        const response = await fetch('http://localhost:8081/api/profile/nickname', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ nickname: newNickname })
        });

        if (!response.ok) {
            throw new Error('修改昵称失败');
        }

        const user = await response.json();
        document.getElementById('nickname').textContent = user.nickname;
        hideEditNickname();
        showMessage('昵称修改成功');
    } catch (error) {
        console.error('Error updating nickname:', error);
        showMessage('修改昵称失败', true);
    }
}

// 处理密码更新
async function handlePasswordUpdate(e) {
    e.preventDefault();

    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (newPassword !== confirmPassword) {
        showMessage('两次输入的新密码不一致', true);
        return;
    }

    try {
        const response = await fetch('http://localhost:8081/api/profile/password', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({
                oldPassword,
                newPassword
            })
        });

        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.message || '修改密码失败');
        }

        showMessage('密码修改成功');
        e.target.reset();
    } catch (error) {
        console.error('Error updating password:', error);
        showMessage(error.message || '修改密码失败', true);
    }
}

// 显示消息
function showMessage(message, isError = false) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = message;
    messageDiv.className = `message ${isError ? 'error' : 'success'}`;
    messageDiv.style.display = 'block';

    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 3000);
}

// 显示修改密码对话框
function showChangePassword() {
    const modal = document.getElementById('passwordModal');
    modal.style.display = 'block';
}

// 关闭对话框
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'none';
}

// 退出登录
function logout() {
    fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
    })
    .then(() => {
        window.location.href = '/login.html';
    })
    .catch(error => {
        console.error('退出登录失败:', error);
        window.location.href = '/login.html';
    });
}

// 点击对话框外部关闭对话框
window.onclick = function(event) {
    const nicknameModal = document.getElementById('nicknameModal');
    const passwordModal = document.getElementById('passwordModal');
    if (event.target === nicknameModal) {
        nicknameModal.style.display = 'none';
    }
    if (event.target === passwordModal) {
        passwordModal.style.display = 'none';
    }
} 