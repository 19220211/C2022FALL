// 页面加载时检查登录状态
document.addEventListener('DOMContentLoaded', function() {
    const postForm = document.getElementById('postForm');
    const messageDiv = document.getElementById('message');
    const baseUrl = 'http://localhost:8081';
    let currentUser = null;

    // 检查登录状态
    async function checkLoginStatus() {
        try {
            const response = await fetch(`${baseUrl}/api/auth/status`, {
                credentials: 'include'
            });
            const data = await response.json();
            
            if (data.loggedIn) {
                currentUser = data.user;
                return currentUser;
            } else {
                window.location.href = 'login.html';
                return null;
            }
        } catch (error) {
            console.error('Error checking login status:', error);
            window.location.href = 'login.html';
            return null;
        }
    }

    // 显示消息
    function showMessage(message, isError = false) {
        messageDiv.textContent = message;
        messageDiv.className = 'message ' + (isError ? 'error' : 'success');
        messageDiv.style.display = 'block';
    }

    // 初始化检查登录状态
    checkLoginStatus();

    // 处理表单提交
    postForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        if (!currentUser) {
            showMessage('请先登录', true);
            return;
        }

        const title = document.getElementById('title').value.trim();
        const content = document.getElementById('content').value.trim();
        const category = document.getElementById('category').value;

        if (!title || !content || !category) {
            showMessage('请填写所有必填字段', true);
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/posts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({
                    title,
                    content,
                    category,
                    author_id: currentUser.id,
                    user_id: currentUser.id
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                showMessage('发布成功！', false);
                // 清空表单
                postForm.reset();
                // 延迟跳转
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
            } else {
                showMessage(data.message || '发布失败，请重试', true);
            }
        } catch (error) {
            console.error('Error creating post:', error);
            showMessage('发布失败，请稍后重试', true);
        }
    });

    // 检查是否是编辑模式
    const urlParams = new URLSearchParams(window.location.search);
    const editPostId = urlParams.get('edit');
    
    if (editPostId) {
        loadPost(editPostId);
    }

    // 加载帖子内容（编辑模式）
    async function loadPost(postId) {
        try {
            const response = await fetch(`${baseUrl}/api/posts/${postId}`, {
                credentials: 'include'
            });

            if (!response.ok) {
                throw new Error('帖子不存在或无权限编辑');
            }

            const post = await response.json();
            
            document.getElementById('title').value = post.title;
            document.getElementById('category').value = post.category;
            document.getElementById('content').value = post.content;
            
            // 更新标题和按钮文本
            document.querySelector('h2').textContent = '编辑帖子';
            document.querySelector('button[type="submit"]').textContent = '保存修改';
            
            // 修改表单提交处理
            postForm.removeEventListener('submit', handleSubmit);
            postForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                await handleEdit(postId);
            });
        } catch (error) {
            console.error('Error loading post:', error);
            showMessage('加载帖子失败：' + error.message, true);
        }
    }

    // 处理编辑提交
    async function handleEdit(postId) {
        const title = document.getElementById('title').value.trim();
        const content = document.getElementById('content').value.trim();
        const category = document.getElementById('category').value;

        if (!title || !content || !category) {
            showMessage('请填写所有必填字段', true);
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/posts/${postId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({
                    title,
                    content,
                    category
                })
            });

            const data = await response.json();

            if (response.ok) {
                showMessage('修改成功！', false);
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            } else {
                showMessage(data.message || '修改失败，请重试', true);
            }
        } catch (error) {
            console.error('Error updating post:', error);
            showMessage('修改失败，请稍后重试', true);
        }
    }
}); 