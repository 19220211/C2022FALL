package org.example.bbss.repository;

import org.example.bbss.entity.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LikeRepository extends JpaRepository<Like, Long> {
    // 检查用户是否已经点赞过帖子
    boolean existsByUserIdAndPostId(Long userId, Long postId);
    
    // 获取帖子的点赞数
    long countByPostId(Long postId);
    
    // 获取用户的点赞列表
    List<Like> findByUserIdOrderByCreateTimeDesc(Long userId);
    
    // 根据帖子ID删除所有点赞记录
    @Modifying
    @Query("DELETE FROM Like l WHERE l.post.id = ?1")
    void deleteByPostId(Long postId);
    
    // 根据用户ID删除所有点赞记录
    @Modifying
    @Query("DELETE FROM Like l WHERE l.user.id = ?1")
    void deleteByUserId(Long userId);
} 