package org.example.bbss.service;

import org.example.bbss.entity.Message;
import org.example.bbss.entity.Post;
import org.example.bbss.entity.User;
import org.example.bbss.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MessageService {

    @Autowired
    private MessageRepository messageRepository;

    public void createLikeMessage(User fromUser, Post post) {
        Message message = new Message();
        message.setUser(post.getUser());
        message.setContent(fromUser.getNickname() + " 点赞了你的帖子：" + post.getTitle());
        message.setType("LIKE");
        message.setCreateTime(LocalDateTime.now());
        message.setPost(post);
        messageRepository.save(message);
    }

    public void createCommentMessage(User fromUser, Post post, String commentContent) {
        Message message = new Message();
        message.setUser(post.getUser());
        message.setContent(fromUser.getNickname() + " 评论了你的帖子：" + commentContent);
        message.setType("COMMENT");
        message.setCreateTime(LocalDateTime.now());
        message.setPost(post);
        messageRepository.save(message);
    }

    public List<Message> getUserMessages(Long userId) {
        return messageRepository.findByUserIdOrderByCreateTimeDesc(userId);
    }

    public long getUnreadMessageCount(Long userId) {
        return messageRepository.countByUserIdAndIsReadFalse(userId);
    }

    public void markMessageAsRead(Long messageId) {
        messageRepository.findById(messageId).ifPresent(message -> {
            message.setRead(true);
            messageRepository.save(message);
        });
    }

    public void markAllMessagesAsRead(Long userId) {
        List<Message> messages = messageRepository.findByUserIdOrderByCreateTimeDesc(userId);
        messages.forEach(message -> message.setRead(true));
        messageRepository.saveAll(messages);
    }
} 