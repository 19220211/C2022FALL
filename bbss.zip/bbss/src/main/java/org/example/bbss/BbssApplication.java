package org.example.bbss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbssApplication {

    public static void main(String[] args) {
        SpringApplication.run(BbssApplication.class, args);
    }

}
