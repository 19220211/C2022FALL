package org.example.bbss.controller;

import org.example.bbss.entity.Post;
import org.example.bbss.entity.Comment;
import org.example.bbss.entity.Category;
import org.example.bbss.service.PostService;
import org.example.bbss.service.CommentService;
import org.example.bbss.service.CategoryService;
import org.example.bbss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = {"http://localhost:8081"}, allowCredentials = "true")
public class AdminController {

    @Autowired
    private PostService postService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private UserService userService;

    // 获取所有帖子
    @GetMapping("/posts")
    public ResponseEntity<?> getAllPosts(HttpSession session) {
        try {
            List<Post> posts = postService.getAllPosts();
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取帖子列表失败：" + e.getMessage());
        }
    }

    // 获取所有评论
    @GetMapping("/comments")
    public ResponseEntity<?> getAllComments(HttpSession session) {
        try {
            List<Comment> comments = commentService.getAllComments();
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取评论列表失败：" + e.getMessage());
        }
    }

    // 获取所有分类
    @GetMapping("/categories")
    public ResponseEntity<?> getAllCategories(HttpSession session) {
        try {
            List<Category> categories = categoryService.getAllCategories();
            return ResponseEntity.ok(categories);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取分类列表失败：" + e.getMessage());
        }
    }

    // 删除帖子
    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId, HttpSession session) {
        try {
            postService.deletePostByAdmin(postId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("删除帖子失败：" + e.getMessage());
        }
    }

    // 删除评论
    @DeleteMapping("/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable Long commentId, HttpSession session) {
        try {
            commentService.deleteCommentByAdmin(commentId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("删除评论失败：" + e.getMessage());
        }
    }

    // 添加分类
    @PostMapping("/categories")
    public ResponseEntity<?> addCategory(@RequestBody Map<String, String> data, HttpSession session) {
        String categoryName = data.get("name");
        if (categoryName == null || categoryName.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("分类名称不能为空");
        }

        try {
            Category category = categoryService.addCategory(categoryName);
            return ResponseEntity.ok(category);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("添加分类失败：" + e.getMessage());
        }
    }

    // 删除分类
    @DeleteMapping("/categories/{categoryName}")
    public ResponseEntity<?> deleteCategory(@PathVariable String categoryName, HttpSession session) {
        try {
            categoryService.deleteCategory(categoryName);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("删除分类失败：" + e.getMessage());
        }
    }
} 