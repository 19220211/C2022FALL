package org.example.bbss.repository;

import org.example.bbss.entity.Comment;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    // 获取帖子的所有评论，按创建时间倒序排列
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.user WHERE c.post.id = ?1 ORDER BY c.createTime DESC")
    @Transactional(readOnly = true)
    List<Comment> findByPostIdOrderByCreateTimeDesc(Long postId);
    
    // 获取用户的所有评论，按创建时间倒序排列
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.post WHERE c.user.id = ?1 ORDER BY c.createTime DESC")
    @Transactional(readOnly = true)
    List<Comment> findByUserIdOrderByCreateTimeDesc(Long userId);
    
    // 获取所有评论，按创建时间倒序排列（管理员使用）
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.user LEFT JOIN FETCH c.post ORDER BY c.createTime DESC")
    @Transactional(readOnly = true)
    List<Comment> findAllByOrderByCreateTimeDesc();
    
    // 获取帖子的评论数
    @Transactional(readOnly = true)
    long countByPostId(Long postId);
    
    // 根据帖子ID删除所有评论
    @Modifying
    @Transactional
    @Query("DELETE FROM Comment c WHERE c.post.id = ?1")
    void deleteByPostId(Long postId);
    
    // 根据用户ID删除所有评论
    @Modifying
    @Transactional
    @Query("DELETE FROM Comment c WHERE c.user.id = ?1")
    void deleteByUserId(Long userId);
    
    // 获取指定帖子的最新评论
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.user WHERE c.post.id = ?1 ORDER BY c.createTime DESC")
    @Transactional(readOnly = true)
    List<Comment> findLatestCommentsByPostId(Long postId, Pageable pageable);
} 