package org.example.bbss.controller;

import org.example.bbss.entity.User;
import org.example.bbss.entity.Post;
import org.example.bbss.entity.Comment;
import org.example.bbss.service.UserService;
import org.example.bbss.service.PostService;
import org.example.bbss.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

@RestController
@RequestMapping("/api/profile")
@CrossOrigin(origins = {"http://localhost:8081"}, allowCredentials = "true")
public class ProfileController {

    @Autowired
    private UserService userService;

    @Autowired
    private PostService postService;

    @Autowired
    private CommentService commentService;

    @PutMapping("/nickname")
    public ResponseEntity<?> updateNickname(@RequestBody Map<String, String> data, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        String newNickname = data.get("nickname");
        if (newNickname == null || newNickname.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("昵称不能为空");
        }

        try {
            User user = userService.updateNickname(userId, newNickname);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("修改昵称失败：" + e.getMessage());
        }
    }

    @PutMapping("/password")
    public ResponseEntity<?> updatePassword(@RequestBody Map<String, String> data, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        String oldPassword = data.get("oldPassword");
        String newPassword = data.get("newPassword");
        
        if (oldPassword == null || newPassword == null || 
            oldPassword.trim().isEmpty() || newPassword.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("密码不能为空");
        }

        try {
            boolean success = userService.updatePassword(userId, oldPassword, newPassword);
            if (success) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().body("原密码错误");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("修改密码失败：" + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> getProfile(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        try {
            User user = userService.getUserById(userId);
            if (user != null) {
                return ResponseEntity.ok(user);
            } else {
                return ResponseEntity.badRequest().body("用户不存在");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取个人信息失败：" + e.getMessage());
        }
    }

    @GetMapping("/posts")
    public ResponseEntity<?> getUserPosts(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        try {
            List<Post> posts = postService.getPostsByUser(userId);
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取帖子列表失败：" + e.getMessage());
        }
    }

    @GetMapping("/comments")
    public ResponseEntity<?> getUserComments(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        try {
            List<Comment> comments = commentService.getCommentsByUser(userId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取评论列表失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable Long commentId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.badRequest().body("请先登录");
        }

        try {
            commentService.deleteComment(commentId, userId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("删除评论失败：" + e.getMessage());
        }
    }
} 