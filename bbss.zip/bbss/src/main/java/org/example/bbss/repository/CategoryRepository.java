package org.example.bbss.repository;

import org.example.bbss.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    boolean existsByName(String name);
    
    Optional<Category> findByName(String name);
    
    @Modifying
    @Query("UPDATE Category c SET c.postCount = c.postCount + 1 WHERE c.name = ?1")
    void incrementPostCount(String categoryName);
    
    @Modifying
    @Query("UPDATE Category c SET c.postCount = c.postCount - 1 WHERE c.name = ?1")
    void decrementPostCount(String categoryName);
} 