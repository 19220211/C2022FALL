package org.example.bbss.controller;

import org.example.bbss.entity.User;
import org.example.bbss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {"http://localhost:8081"}, allowCredentials = "true")
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/status")
    public ResponseEntity<?> checkAuthStatus(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Map<String, Object> response = new HashMap<>();
        
        if (userId != null) {
            User user = userService.getUserById(userId);
            if (user != null) {
                response.put("loggedIn", true);
                response.put("user", user);
                return ResponseEntity.ok(response);
            }
        }
        
        response.put("loggedIn", false);
        return ResponseEntity.ok(response);
    }

        @PostMapping("/login")    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials, HttpSession session) {        String username = credentials.get("username");        String password = credentials.get("password");                User user = userService.login(username, password);        Map<String, Object> response = new HashMap<>();                if (user != null) {            session.setAttribute("userId", user.getId());            session.setAttribute("username", user.getUsername());            session.setAttribute("role", user.getRole());            response.put("success", true);            response.put("user", user);            return ResponseEntity.ok(response);        } else {            response.put("success", false);            response.put("message", "用户名或密码错误");            return ResponseEntity.badRequest().body(response);        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {
        session.removeAttribute("userId");
        return ResponseEntity.ok().build();
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        // 打印接收到的数据
        System.out.println("Received registration data: " + user);
        
        // 验证必填字段
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "用户名不能为空"
            ));
        }
        
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "密码不能为空"
            ));
        }
        
        if (user.getNickname() == null || user.getNickname().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "昵称不能为空"
            ));
        }

        try {
            // 设置默认值
            user.setCreateTime(LocalDateTime.now());
            user.setRole("USER");
            
            boolean success = userService.register(user);
            Map<String, Object> response = new HashMap<>();
            
            if (success) {
                response.put("success", true);
                response.put("message", "注册成功");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "用户名已存在");
                return ResponseEntity.badRequest().body(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of(
                "success", false,
                "message", "注册失败：" + e.getMessage()
            ));
        }
    }

    @PostMapping("/admin-access")
    public ResponseEntity<?> adminAccess(@RequestBody Map<String, String> data, HttpSession session) {
        String secretKey = data.get("secretKey");
        String correctKey = "bbss2024"; // 确保这个密钥与前端一致
        
        if (correctKey.equals(secretKey)) {
            // 获取当前登录用户
            Long userId = (Long) session.getAttribute("userId");
            if (userId != null) {
                User user = userService.getUserById(userId);
                if (user != null) {
                    // 设置用户为管理员
                    user.setRole("ADMIN");
                    userService.updateUser(user);
                    
                    // 更新会话信息
                    session.setAttribute("role", "ADMIN");
                    return ResponseEntity.ok().build();
                }
            }
        }
        return ResponseEntity.status(403).body("访问被拒绝");
    }
} 