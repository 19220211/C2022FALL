package org.example.bbss.service;

import org.example.bbss.entity.Category;
import org.example.bbss.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Transactional(readOnly = true)
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Transactional
    public Category addCategory(String name) {
        if (categoryRepository.existsByName(name)) {
            throw new RuntimeException("分类已存在");
        }

        Category category = new Category();
        category.setName(name);
        category.setPostCount(0);
        return categoryRepository.save(category);
    }

    @Transactional
    public void deleteCategory(String name) {
        Category category = categoryRepository.findByName(name)
                .orElseThrow(() -> new RuntimeException("分类不存在"));

        if (category.getPostCount() > 0) {
            throw new RuntimeException("该分类下还有帖子，无法删除");
        }

        categoryRepository.delete(category);
    }

    @Transactional
    public void incrementPostCount(String categoryName) {
        categoryRepository.incrementPostCount(categoryName);
    }

    @Transactional
    public void decrementPostCount(String categoryName) {
        categoryRepository.decrementPostCount(categoryName);
    }
} 