package org.example.bbss.service;

import org.example.bbss.entity.Comment;
import org.example.bbss.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Transactional(readOnly = true)
    public List<Comment> getCommentsByUser(Long userId) {
        return commentRepository.findByUserIdOrderByCreateTimeDesc(userId);
    }

    @Transactional
    public void deleteComment(Long commentId, Long userId) {
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));

        if (!comment.getUser().getId().equals(userId)) {
            throw new RuntimeException("无权限删除此评论");
        }

        commentRepository.delete(comment);
    }

    // 管理员方法
    @Transactional(readOnly = true)
    public List<Comment> getAllComments() {
        return commentRepository.findAllByOrderByCreateTimeDesc();
    }

    @Transactional
    public void deleteCommentByAdmin(Long commentId) {
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        commentRepository.delete(comment);
    }

    @Transactional
    public void deleteByPostId(Long postId) {
        commentRepository.deleteByPostId(postId);
    }
} 