package org.example.bbss.repository;

import org.example.bbss.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.user ORDER BY p.createTime DESC")
    List<Post> findAllByOrderByCreateTimeDesc();
    
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.user WHERE p.category = ?1 ORDER BY p.createTime DESC")
    List<Post> findByCategoryOrderByCreateTimeDesc(String category);
    
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.user WHERE p.user.id = ?1 ORDER BY p.createTime DESC")
    List<Post> findByUserIdOrderByCreateTimeDesc(Long userId);
    
    @Modifying
    @Query("UPDATE Post p SET p.likes = p.likes + 1 WHERE p.id = ?1")
    void incrementLikes(Long postId);
    
    @Modifying
    @Query("UPDATE Post p SET p.comments = p.comments + 1 WHERE p.id = ?1")
    void incrementComments(Long postId);

    @Query("SELECT p FROM Post p WHERE p.user IS NULL OR p.user.id = 0")
    List<Post> findInvalidPosts();

    @Modifying
    @Query("DELETE FROM Post p WHERE p.user IS NULL OR p.user.id = 0")
    void deleteInvalidPosts();
} 