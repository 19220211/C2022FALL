package org.example.bbss.controller;

import org.example.bbss.entity.Comment;
import org.example.bbss.entity.Post;
import org.example.bbss.entity.User;
import org.example.bbss.service.PostService;
import org.example.bbss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/posts")
@CrossOrigin(origins = {"http://localhost:8081"}, allowCredentials = "true")
public class PostController {

    @Autowired
    private PostService postService;

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<?> getAllPosts(@RequestParam(required = false) String category) {
        try {
            List<Post> posts;
            if (category != null && !category.isEmpty()) {
                posts = postService.getPostsByCategory(category);
            } else {
                posts = postService.getAllPosts();
            }
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            e.printStackTrace(); // 打印详细错误堆栈
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "获取帖子列表失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @GetMapping("/{postId}/comments")
    public ResponseEntity<?> getPostComments(@PathVariable Long postId) {
        try {
            List<Comment> comments = postService.getPostComments(postId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "获取评论失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @PostMapping
    public ResponseEntity<?> createPost(@RequestBody Post post, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Map<String, Object> response = new HashMap<>();
        
        if (userId == null) {
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                response.put("success", false);
                response.put("message", "用户不存在");
                return ResponseEntity.badRequest().body(response);
            }
            
            // 打印接收到的数据
            System.out.println("Received post data: " + post);
            System.out.println("User ID: " + userId);
            
            Post savedPost = postService.createPost(post, userId);
            response.put("success", true);
            response.put("data", savedPost);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "发布失败：" + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @DeleteMapping("/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Map<String, Object> response = new HashMap<>();
        
        if (userId == null) {
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                response.put("success", false);
                response.put("message", "用户不存在");
                return ResponseEntity.badRequest().body(response);
            }
            
                        postService.deletePost(postId, userId);
            response.put("success", true);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "删除失败：" + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/{postId}/like")
    public ResponseEntity<?> likePost(@PathVariable Long postId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Map<String, Object> response = new HashMap<>();
        
        if (userId == null) {
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                response.put("success", false);
                response.put("message", "用户不存在");
                return ResponseEntity.badRequest().body(response);
            }

            boolean success = postService.likePost(postId, user);
            if (!success) {
                response.put("success", false);
                response.put("message", "您已经点赞过这篇帖子了");
                return ResponseEntity.badRequest().body(response);
            }
            response.put("success", true);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "点赞失败：" + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/{postId}/comment")
    public ResponseEntity<?> addComment(@PathVariable Long postId, @RequestBody Map<String, String> commentData, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Map<String, Object> response = new HashMap<>();
        
        if (userId == null) {
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                response.put("success", false);
                response.put("message", "用户不存在");
                return ResponseEntity.badRequest().body(response);
            }

            String content = commentData.get("content");
            if (content == null || content.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "评论内容不能为空");
                return ResponseEntity.badRequest().body(response);
            }

            Comment comment = postService.addComment(postId, user, content);
            if (comment == null) {
                response.put("success", false);
                response.put("message", "评论失败");
                return ResponseEntity.badRequest().body(response);
            }
            response.put("success", true);
            response.put("data", comment);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "评论失败：" + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
} 