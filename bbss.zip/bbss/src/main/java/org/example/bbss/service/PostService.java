package org.example.bbss.service;

import org.example.bbss.entity.Comment;
import org.example.bbss.entity.Like;
import org.example.bbss.entity.Post;
import org.example.bbss.entity.User;
import org.example.bbss.repository.CommentRepository;
import org.example.bbss.repository.LikeRepository;
import org.example.bbss.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private LikeRepository likeRepository;

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private MessageService messageService;

    @Autowired
    private UserService userService;

    @Autowired
    private CommentService commentService;

    @PostConstruct
    public void init() {
        cleanInvalidPosts();
    }

    @Transactional
    public void cleanInvalidPosts() {
        try {
            // 先删除没有作者的帖子
            List<Post> invalidPosts = postRepository.findInvalidPosts();
            if (!invalidPosts.isEmpty()) {
                System.out.println("Found " + invalidPosts.size() + " invalid posts, cleaning up...");
                for (Post post : invalidPosts) {
                    // 删除相关的点赞和评论
                    likeRepository.deleteByPostId(post.getId());
                    commentRepository.deleteByPostId(post.getId());
                }
                postRepository.deleteInvalidPosts();
                System.out.println("Invalid posts cleaned up successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error cleaning invalid posts: " + e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<Post> getAllPosts() {
        return postRepository.findAllByOrderByCreateTimeDesc();
    }

    public List<Post> getPostsByCategory(String category) {
        try {
            List<Post> posts = postRepository.findByCategoryOrderByCreateTimeDesc(category);
            posts.removeIf(post -> post.getUser() == null || post.getUser().getId() == null || post.getUser().getId() == 0);
            return posts;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("获取分类帖子失败：" + e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<Post> getPostsByUser(Long userId) {
        return postRepository.findByUserIdOrderByCreateTimeDesc(userId);
    }

    public Post getPostById(Long id) {
        return postRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));
    }

    @Transactional
    public Post createPost(Post post, Long userId) {
        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                throw new RuntimeException("用户不存在");
            }
            post.setUserId(userId);
            post.setAuthorId(userId);
            post.setUser(user);
            post.setCreateTime(LocalDateTime.now());
            post.setUpdateTime(LocalDateTime.now());
            post.setLikes(0);
            post.setComments(0);
            return postRepository.save(post);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("创建帖子失败：" + e.getMessage());
        }
    }

    @Transactional
    public Post updatePost(Long id, Post updatedPost, Long userId) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));

        if (!post.getUser().getId().equals(userId)) {
            throw new RuntimeException("无权限修改此帖子");
        }

        post.setTitle(updatedPost.getTitle());
        post.setContent(updatedPost.getContent());
        post.setCategory(updatedPost.getCategory());
        post.setUpdateTime(LocalDateTime.now());

        return postRepository.save(post);
    }

    @Transactional
    public void deletePost(Long postId, Long userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));

        if (!post.getUser().getId().equals(userId)) {
            throw new RuntimeException("无权限删除此帖子");
        }

        // 先删除帖子的所有评论
        commentService.deleteByPostId(postId);
        // 再删除帖子
        postRepository.delete(post);
    }

    @Transactional
    public Post likePost(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));
        post.setLikes(post.getLikes() + 1);
        return postRepository.save(post);
    }

    @Transactional
    public Post incrementCommentCount(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));
        post.setComments(post.getComments() + 1);
        return postRepository.save(post);
    }

    @Transactional
    public boolean likePost(Long postId, User user) {
        Post post = getPostById(postId);
        if (post == null) {
            return false;
        }

        // 检查是否已经点赞
        if (likeRepository.existsByUserIdAndPostId(user.getId(), postId)) {
            return false;
        }

        // 创建点赞记录
        Like like = new Like();
        like.setUser(user);
        like.setPost(post);
        like.setCreateTime(LocalDateTime.now());
        likeRepository.save(like);

        // 更新帖子点赞数
        postRepository.incrementLikes(postId);

        // 创建消息通知
        messageService.createLikeMessage(user, post);

        return true;
    }

    @Transactional
    public Comment addComment(Long postId, User user, String content) {
        Post post = getPostById(postId);
        if (post == null) {
            return null;
        }

        // 创建评论
        Comment comment = new Comment();
        comment.setPost(post);
        comment.setUser(user);
        comment.setContent(content);
        comment.setCreateTime(LocalDateTime.now());
        comment = commentRepository.save(comment);

        // 更新帖子评论数
        postRepository.incrementComments(postId);

        // 创建消息通知
        messageService.createCommentMessage(user, post, content);

        return comment;
    }

    @Transactional(readOnly = true)
    public List<Comment> getPostComments(Long postId) {
        try {
            // 验证帖子是否存在
            Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));

            // 获取评论列表
            return commentRepository.findByPostIdOrderByCreateTimeDesc(postId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("获取评论失败：" + e.getMessage());
        }
    }

    @Transactional
    public void deletePostByAdmin(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("帖子不存在"));
        
        // 先删除帖子的所有评论
        commentService.deleteByPostId(postId);
        // 再删除帖子
        postRepository.delete(post);
    }
} 