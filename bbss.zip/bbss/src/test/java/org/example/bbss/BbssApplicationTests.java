package org.example.bbss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = BbssApplication.class)
class BbssApplicationTests {

    @Test
    void contextLoads() {
    }

}
