#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <math.h>
#include<time.h>

#define MEMORY_SIZE (1 << 14) // 2^14 bytes
#define PAGE_SIZE 256         // 256 bytes per page
#define NUM_PAGES (MEMORY_SIZE / PAGE_SIZE)
#define PTES_PER_PAGE 64      // 64 PTEs per page table
#define LOGICAL_BITS 6        // 6 bits for logical page number
#define OFFSET_BITS 8         // 8 bits for offset within a page

typedef struct {
    unsigned int physical_page : 6; // 6 bits for physical page number
    unsigned int valid : 1;         // 1 bit for validity
} PageTableEntry;

typedef struct {
    PageTableEntry ptes[PTES_PER_PAGE];
} PageTable;

typedef struct {
    int job_id;
    int num_pages;
    int* page_numbers;
    int pt_base_addr;
    int allocated_pages[10]; // Physical pages allocated to the process, including page table
    HANDLE thread_handle;
    int fifo_head;          // Head of FIFO queue for page replacement
    int page_fault_count;   // Count of page faults
} Job;

unsigned char* memory;
int free_pages[NUM_PAGES];
Job* job_queue[100]; // Simulated job queue
int job_count = 0;
CRITICAL_SECTION cs; // Critical section for mutual exclusion
HANDLE semaphore;    // Semaphore to control concurrent processes

void init_memory() {
    memory = (unsigned char*)malloc(MEMORY_SIZE);
    memset(memory, 0, MEMORY_SIZE);

    for (int i = 0; i < NUM_PAGES; i++) {
        free_pages[i] = 1; // All pages are initially free
    }

    InitializeCriticalSection(&cs);
    semaphore = CreateSemaphore(NULL, 6, 6, NULL); // Allow up to 6 concurrent processes
}

PageTable* create_pagetable() {
    PageTable* pt = (PageTable*)malloc(sizeof(PageTable));
    memset(pt->ptes, 0, sizeof(pt->ptes));
    return pt;
}

int allocate_physical_page() {
    EnterCriticalSection(&cs);
    for (int i = 0; i < NUM_PAGES; i++) {
        if (free_pages[i]) {
            free_pages[i] = 0;
            LeaveCriticalSection(&cs);
            return i;
        }
    }
    LeaveCriticalSection(&cs);
    return -1; // No free pages
}

void deallocate_physical_page(int phys_page) {
    EnterCriticalSection(&cs);
    if (phys_page >= 0 && phys_page < NUM_PAGES) {
        free_pages[phys_page] = 1;
    }
    LeaveCriticalSection(&cs);
}

unsigned int translate_address(PageTable* pt, unsigned int logical_addr) {
    unsigned int logical_page = (logical_addr >> OFFSET_BITS) & ((1 << LOGICAL_BITS) - 1);
    unsigned int offset = logical_addr & ((1 << OFFSET_BITS) - 1);

    if (pt->ptes[logical_page].valid) {
        unsigned int physical_page = pt->ptes[logical_page].physical_page;
        return (physical_page << OFFSET_BITS) | offset;
    }
    else {
        printf("Page fault: Logical address %u not mapped\n", logical_addr);
        return -1;
    }
}

void write_job_to_file(int job_id, int num_pages) {
    char filename[50];
    sprintf(filename, "D:\\E11\\job%d.bin", job_id);

    FILE* file = fopen(filename, "wb");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    for (int i = 0; i < num_pages; i++) {
        fseek(file, i * PAGE_SIZE, SEEK_SET);
        unsigned char data = rand() % 256; // Random byte for each page
        fwrite(&data, sizeof(unsigned char), 1, file);
        fwrite(&job_id, sizeof(int), 1, file);
        fwrite(&i, sizeof(int), 1, file);
    }

    fclose(file);
}

void read_jobs_from_files() {
    for (int job_id = 1; job_id <= 12; job_id++) {
        char filename[50];
        sprintf(filename, "D:\\E11\\job%d.bin", job_id);

        FILE* file = fopen(filename, "rb");
        if (!file) {
            perror("Failed to open file");
            continue;
        }

        int num_pages = rand() % 55 + 10; // Randomly assign between 10 and 64 pages
        int* page_numbers = (int*)malloc(num_pages * sizeof(int));

        for (int i = 0; i < num_pages; i++) {
            fseek(file, i * PAGE_SIZE, SEEK_SET);
            fread(page_numbers + i, sizeof(int), 1, file);
        }

        fclose(file);

        Job* job = (Job*)malloc(sizeof(Job));
        job->job_id = job_id;
        job->num_pages = num_pages;
        job->page_numbers = page_numbers;
        job->thread_handle = NULL;
        job->fifo_head = 0; // Initialize FIFO head
        job->page_fault_count = 0; // Initialize page fault count

        job_queue[job_count++] = job;
    }
}

void print_job_queue() {
    for (int i = 0; i < job_count; i++) {
        printf("Job ID: %d, Number of Pages: %d ", job_queue[i]->job_id, job_queue[i]->num_pages);
        printf("\n");
    }

}

int count_free_pages() {
    int count = 0;
    for (int i = 0; i < NUM_PAGES; i++) {
        if (free_pages[i]) {
            count++;
        }
    }
    return count;
}

void load_job_into_memory(Job* job) {
    if (count_free_pages() < 10) {
        printf("Not enough free pages to load job %d\n", job->job_id);
        return;
    }

    // Allocate one page for the page table
    int pt_page = allocate_physical_page();
    if (pt_page == -1) {
        printf("Failed to allocate page table page for job %d\n", job->job_id);
        return;
    }

    job->pt_base_addr = pt_page * PAGE_SIZE;

    // Allocate 9 pages for the process
    for (int i = 0; i < 9; i++) {
        int phys_page = allocate_physical_page();
        if (phys_page == -1) {
            printf("Failed to allocate page %d for job %d\n", i, job->job_id);
            // Deallocate previously allocated pages
            for (int j = 0; j < i; j++) {
                deallocate_physical_page(job->allocated_pages[j]);
            }
            deallocate_physical_page(pt_page);
            return;
        }
        job->allocated_pages[i] = phys_page;
        PageTable* pt = (PageTable*)(memory + job->pt_base_addr);
        pt->ptes[i].physical_page = phys_page;
        pt->ptes[i].valid = 1;
    }

    printf("Loaded job %d into memory with PT base addr 0x%X and pages:", job->job_id, job->pt_base_addr);
    for (int i = 0; i < 9; i++) {
        printf(" %d", job->allocated_pages[i]);
    }
    printf("\n");

    // Print page table mapping
    PageTable* pt = (PageTable*)(memory + job->pt_base_addr);
    printf("Job %d Page Table Mapping:\n", job->job_id);
    for (int i = 0; i < 9; i++) {
        if (pt->ptes[i].valid) {
            printf("Logical Page %d -> Physical Page %d\n", i, pt->ptes[i].physical_page);
        }
    }
}

DWORD WINAPI process_thread(LPVOID lpParam) {
    Job* job = (Job*)lpParam;

    // Load job into memory
    load_job_into_memory(job);

    // Generate 200 random logical addresses
    for (int i = 0; i < 200; i++) {
        double probabilities[65];
        double sum_probabilities = 0.0;

        // Calculate probabilities based on (i+1)^(-0.5)
        for (int j = 0; j < job->num_pages; j++) {
            probabilities[j] = 1.0 / sqrt(j + 1);
            sum_probabilities += probabilities[j];
        }

        // Normalize probabilities
        for (int j = 0; j < job->num_pages; j++) {
            probabilities[j] /= sum_probabilities;
        }

        // Select a logical page based on probabilities
        double r = (double)rand() / RAND_MAX;
        int selected_logical_page = 0;
        while (r > probabilities[selected_logical_page] && selected_logical_page < job->num_pages - 1) {
            r -= probabilities[selected_logical_page];
            selected_logical_page++;
        }

        // Generate a random offset
        unsigned int offset = rand() % PAGE_SIZE;

        // Construct logical address
        unsigned int logical_addr = (selected_logical_page << OFFSET_BITS) | offset;

        // Translate logical address to physical address
        PageTable* pt = (PageTable*)(memory + job->pt_base_addr);
        unsigned int physical_addr = translate_address(pt, logical_addr);

        if (physical_addr != -1) {
            // Valid page table entry
            unsigned char virtual_content = offset;
            unsigned char physical_content = rand() & 0xFF;
            //            unsigned char physical_content = *(memory + physical_addr);
            printf("Process %d: Virtual Address %u, Content %u, Physical Address %u, Content 0x%02X\n",
                job->job_id, logical_addr, virtual_content, physical_addr, physical_content);
        }
        else {
            // Invalid page table entry, need to handle page fault
            unsigned char virtual_content = offset;
            printf("Process %d: Virtual Address %u, Content %u, -, --\n", job->job_id, logical_addr, virtual_content);

            // Find the physical page to replace using FIFO
            int replaced_logical_page = job->fifo_head;
            int replaced_physical_page = pt->ptes[replaced_logical_page].physical_page;

            // Read the new page from file
            char filename[50];
            sprintf(filename, "D:\\E11\\job%d.bin", job->job_id);

            FILE* file = fopen(filename, "rb");
            if (!file) {
                perror("Failed to open file");
                continue;
            }

            fseek(file, selected_logical_page * PAGE_SIZE, SEEK_SET);
            fread(memory + replaced_physical_page * PAGE_SIZE, 1, PAGE_SIZE, file);

            fclose(file);

            // Update page table
            pt->ptes[replaced_logical_page].physical_page = replaced_physical_page;
            pt->ptes[replaced_logical_page].valid = 1;

            // Update FIFO head
            job->fifo_head = (job->fifo_head + 1) % 9;

            // Increment page fault count
            job->page_fault_count++;

            // Output page fault information
            printf("Process %d page fault, page %d replaced\n", job->job_id, replaced_logical_page);

            // Access the newly loaded page
            physical_addr = (replaced_physical_page << OFFSET_BITS) | offset;
            unsigned char physical_content = rand() & 0xFF;
            //            unsigned char physical_content = *(memory + physical_addr);

            printf("Process %d: Virtual Address %u, Content %u, Physical Address %u, Content 0x%02X\n",
                job->job_id, logical_addr, virtual_content, physical_addr, physical_content);
        }

        // Sleep for a random time between 0 and 100 ms
        DWORD sleep_time = rand() % 101;
        Sleep(sleep_time);
    }

    // Calculate and print page fault rate
    double page_fault_rate = (double)job->page_fault_count / 200;
    printf("Process %d completed 200 accesses with %d page faults (%f%%)\n",
        job->job_id, job->page_fault_count, page_fault_rate * 100);

    // Release all allocated pages
    PageTable* pt = (PageTable*)(memory + job->pt_base_addr);
    for (int i = 0; i < 9; i++) {
        if (pt->ptes[i].valid) {
            deallocate_physical_page(pt->ptes[i].physical_page);
        }
    }
    deallocate_physical_page(job->pt_base_addr / PAGE_SIZE);

    printf("Job %d released all pages\n", job->job_id);

    // Signal that a page is now free
    ReleaseSemaphore(semaphore, 1, NULL);

    return 0;
}

void start_processes() {
    for (int i = 0; i < job_count; i++) {
        // Wait for an available slot in the semaphore
        WaitForSingleObject(semaphore, INFINITE);

        // Start the process thread
        job_queue[i]->thread_handle = CreateThread(NULL, 0, process_thread, job_queue[i], 0, NULL);
        if (job_queue[i]->thread_handle == NULL) {
            printf("Failed to create thread for job %d\n", job_queue[i]->job_id);
            ReleaseSemaphore(semaphore, 1, NULL); // Release semaphore if thread creation fails
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < job_count; i++) {
        if (job_queue[i]->thread_handle != NULL) {
            WaitForSingleObject(job_queue[i]->thread_handle, INFINITE);
            CloseHandle(job_queue[i]->thread_handle);
        }
    }
}

int main() {
    srand((unsigned int)time(NULL)); // Seed the random number generator

    init_memory();

    // Write jobs to files
    for (int job_id = 1; job_id <= 12; job_id++) {
        int num_pages = rand() % 55 + 10; // Randomly assign between 10 and 64 pages
        write_job_to_file(job_id, num_pages);
    }

    // Read jobs from files into job queue
    read_jobs_from_files();

    // Print job queue
    print_job_queue();

    // Start processes
    start_processes();

    // Free allocated memory for jobs in the queue
    for (int i = 0; i < job_count; i++) {
        free(job_queue[i]->page_numbers);
        free(job_queue[i]);
    }

    DeleteCriticalSection(&cs);
    CloseHandle(semaphore);

    free(memory);

    return 0;
}

