#include<iostream>
#include"shape.h"
using namespace std;
Point::Point(string shapeNo, double a, double b)
{
	shapeNumber = shapeNo;
	x = a;
	y = b;
}
void Point::setPoint(string shapeNo, double a, double b)
{
	shapeNumber = shapeNo;
	x = a;
	y = b;
}

Circle::Circle(string shapeNo, double a, double b, double r) :Point(shapeNo, a, b), radius(r)
{
}
void Circle::setRadius(double r)
{
	radius = r;
}
double Circle::getRadius()const
{
	return radius;
}
double Circle::area()const
{
	return 3.14159 * radius * radius;
}

Cylinder::Cylinder(string shapeNo, double a, double b, double r, double h) :Circle(shapeNo, a, b, r), height(h)
{
}
void Cylinder::setHeight(double h)
{
	height = h;
}
double Cylinder::getHeight()const
{
	return height;
}
double Cylinder::area()const
{
	return 2 * Circle::area() + 2 * 3.14159 * radius * height;
}
double Cylinder::volume()const
{
	return Circle::area() * height;
}


Rectangle::Rectangle(string shapeNo, double a, double b, double s1, double s2) :Point(shapeNo, a, b), side1(s1), side2(s2)
{
}
void Rectangle::setSides(double s1, double s2)
{
	side1 = s1;
	side2 = s2;
}
double Rectangle::getSide1()const
{
	return side1;
}
double Rectangle::getSide2()const
{
	return side2;
}
double Rectangle::area()const
{
	return side1 * side2;
}
