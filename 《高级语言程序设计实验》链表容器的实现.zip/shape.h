#pragma once
#ifndef SHAPE
#define SHAPE
using namespace std;
class Shape
{
protected:
	string shapeNumber;
	double radius, x, y, height, side1, side2;
public:
	virtual double area() const = 0;
	virtual double volume() const = 0;
	virtual void shapeName() const = 0;
	virtual double getX()const = 0;
	virtual double getY()const = 0;
	virtual void setPoint(string shapeNo, double a, double b)
	{
		shapeNumber = shapeNo;
		x = a;
		y = b;
	}
	virtual void setRadius(double r)
	{
		radius = r;
	}
	virtual void setHeight(double h)
	{
		height = h;
	}
	virtual void setSides(double s1, double s2)
	{
		side1 = s1;
		side2 = s2;
	}
	virtual void display()
	{
		shapeName();
		cout << shapeNumber << "\tx=" << getX() << ",y=" << getY() << "\n\tarea=" << area() << "\n\tvolume=" << volume() << "\n";
	}
	bool operator==(const Shape& s)
	{
		return shapeNumber == s.shapeNumber;
	}
	string getShapeNo()
	{
		return shapeNumber;
	}
};

class Point :public Shape
{
public:
	Point(string shapeNo, double = 0, double = 0);
	void setPoint(string shapeNo, double, double);
	void display()const
	{
		shapeName();
		cout << shapeNumber << "\tx=" << getX() << ",y=" << getY() << "\n\tarea=" << area() << "\n\tvolume=" << volume() << "\n";
	}
	double getX()const
	{
		return x;
	}
	double getY()const
	{
		return y;
	}
	virtual double area()const
	{
		return 0.0;
	}
	virtual double volume()const
	{
		return 0.0;
	}
	virtual void shapeName()const
	{
		cout << "Point:\n";
	}

protected:
	double x, y;

};
  

///////////////////////

class Circle :public Point
{
public:
	Circle(string shapeNo, double x = 0, double y = 0, double r = 0);
	void setRadius(double);
	double getRadius()const;
	virtual double area()const;
	virtual double volume()const
	{
		return 0.0;
	}
	virtual void shapeName()const
	{
		cout << "Circle:\n";
	}
	virtual void display()
	{
		shapeName();
		cout << shapeNumber << "\tx=" << getX() << ",y=" << getY() << ",r= " << getRadius() << "\n\tarea = " << area() << "\n\tvolume = " << volume() << "\n";
	}
protected:
	double radius;
};

//////////////////////


class Cylinder :public Circle
{
public:
	Cylinder(string shapeNo, double x = 0, double y = 0, double r = 0, double h = 0);
	void setHeight(double);
	virtual double area()const;
	virtual double volume()const;
	double getHeight()const;
	virtual void shapeName()const
	{
		cout << "Cylinder:\n";
	}
	virtual void display()
	{
		shapeName();
		cout << shapeNumber << "\tx=" << getX() << ",y=" << getY() << ",r= " << getRadius() << ",h=" << getHeight() << "\n\tarea = " << area() << "\n\tvolume = " << volume() << "\n";
	}
protected:
	double height;
};

//////////////

class Rectangle :public Point
{
public:
	Rectangle(string shapeNo, double x = 0, double y = 0, double side1 = 0, double side2 = 0);
	void setSides(double, double);
	double getSide1()const;
	double getSide2()const;
	virtual double area()const;
	virtual double volume()const
	{
		return 0.0;
	}
	virtual void shapeName()const
	{
		cout << "Rectangle:\n";
	}
	virtual void display()
	{
		shapeName();
		cout << shapeNumber << "\tx=" << getX() << ",y=" << getY() << ",s1= " << getSide1() << ",s2=" << getSide2() << "\n\tarea = " << area() << "\n\tvolume = " << volume() << "\n";
	}
protected:
	double side1, side2;
};


#endif  