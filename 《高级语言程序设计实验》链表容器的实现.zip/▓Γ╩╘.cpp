/*���Խ��
There are 3 shapes.
Circle:
3       x=1.1,y=2.2,r= 3.3
		area = 34.2119
		volume = 0
Point:
2       x=3.3,y=4.4
		area=0
		volume=0
Point:
1       x=3.2,y=4.5
		area=0
		volume=0
There are 2 shapes.
Rectangle:
5       x=2.3,y=3.4,s1= 4.3,s2=5.4
		area = 23.22
		volume = 0
Cylinder:
4       x=1.2,y=1.3,r= 2.2,h=2.3
		area = 62.2035
		volume = 34.9722
There are 2 shapes.
Circle:
3       x=1.1,y=2.2,r= 4.4
		area = 60.8212
		volume = 0
Point:
1       x=4.4,y=5.5
		area=0
		volume=0
There are 2 shapes.
Rectangle:
5       x=2.3,y=3.4,s1= 4.4,s2=5.5
		area = 24.2
		volume = 0
Cylinder:
4       x=1.2,y=1.3,r= 2.2,h=4.4
		area = 91.2318
		volume = 66.9033
*/
#include<iostream>
using namespace std;
#include"accountlist.h"

int main()
{
	Point p1("1", 3.2, 4.5);
	Point p2("2", 3.3, 4.4);
	Circle c1("3", 1.1, 2.2, 3.3);
	Cylinder cy1("4", 1.2, 1.3, 2.2, 2.3);
	Rectangle r1("5", 2.3, 3.4, 4.3, 5.4);
	AccountList a, b;
	Shape* s;
	a.add(p1);
	a.add(p2);
	a.add(c1);
	b.add(cy1);
	b.add(r1);
	a.display();
	b.display();
	a.remove("2");
	if (s = a.find("1")) s->setPoint("1", 4.4, 5.5);
	if (s = a.find("3")) s->setRadius(4.4);
	if (s = b.find("4")) s->setHeight(4.4);
	if (s = b.find("5")) s->setSides(4.4, 5.5);
	a.display();
	b.display();
	return 0;
}
