#pragma once
#ifndef ACCOUNTLIST
#define ACCOUNTLIST
#include"shape.h"
//-------------------------------------
class Node
{
public:
	Shape& acnt;
	Node* next, * prev;						//˫��������ÿ���ڵ�ǰ��ָ��
	Node(Shape& a) :acnt(a), next(0), prev(0)
	{}
	bool operator==(const Node& n)const
	{
		return acnt == n.acnt;
	}
};
//-----------------------------------

class AccountList
{
	int size;
	Node* first;
public:
	AccountList() :first(0), size(0)
	{}
	Node* getFirst()const
	{
		return first;
	}
	int getSize()const
	{
		return size;
	}
	void add(Shape& a);
	void remove(string acntNo);
	Shape* find(string acntNo)const;
	bool isEmpty()const
	{
		return !size;
	}
	void display()const;
	~AccountList();
};
#endif  										//HEADER_ACCOUNTLIST
