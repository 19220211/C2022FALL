#include <stdio.h>
#include <pthread.h>
#include <ctype.h>
#include <semaphore.h>

sem_t mutex;  // 访问total_words的互斥信号量
int total_words = 0;  // 共享变量，线程应互斥访问

void *count_words(void *arg);

int main(int ac, char *av[]) {
    if (ac != 3) {
        printf("Usage: %s file1 file2\n", av[0]);
        exit(1);
    }

    // 初始化信号量mutex的值为1
    sem_init(&mutex, 0, 1);

    pthread_t t1, t2;
    // 分别以av[1], av[2]为参数，创建两个线程t1, t2
    pthread_create(&t1, NULL, count_words, (void *)av[1]);
    pthread_create(&t2, NULL, count_words, (void *)av[2]);

    // 让主线程等待线程t1和t2完成后再执行
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    // 输出统计出来的单词总数
    printf("Total words: %d\n", total_words);

    // 销毁信号量
    sem_destroy(&mutex);
    return 0;
}

void *count_words(void *arg) {
    char *filename = (char *)arg;  // 传给该线程的文件名
    FILE *fp;
    int c, prevc = '\0';

    if ((fp = fopen(filename, "r")) != NULL) {
        while ((c = getc(fp)) != EOF) {
            if (!isalnum(c) && isalnum(prevc)) {
                // 对互斥变量mutex进行P操作
                sem_wait(&mutex);
                total_words++;
                // 对互斥变量进行V操作
                sem_post(&mutex);
            }
            prevc = c;
        }
        fclose(fp);
    } else {
        perror(filename);
    }
    return NULL;
}
