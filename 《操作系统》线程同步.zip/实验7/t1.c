#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <time.h>

#define BUFFER_SIZE 10
#define NUM_PRODUCERS 3
#define NUM_CONSUMERS 2
#define EXECUTION_TIME 60 // 执行时间（秒）

sem_t empty, full;
sem_t pmutex,cmutex;
int buffer[BUFFER_SIZE];
int in = 0, out = 0, productID = 0;

void *producer(void *arg) {
    int producer_id = *(int *)arg;
    while (1) {
        sem_wait(&empty); // 等待空位
        sem_wait(&pmutex); // 加锁

        // 生产产品
        buffer[in] = productID++;
        in = (in + 1) % BUFFER_SIZE;

        // 打印信息
        printf("Producer %d produced product %d\n", producer_id, buffer[(in - 1 + BUFFER_SIZE) % BUFFER_SIZE]);

        if ((in - out + BUFFER_SIZE) % BUFFER_SIZE == 10) {
            printf("Inventory is full (10 products)\n");
        }
        
        
        sem_post(&pmutex); // 解锁
        sem_post(&full); // 增加满位计数


        printf("\n");
        // 休眠3秒
        sleep(3);
    }
}

void *consumer(void *arg) {
    int consumer_id = *(int *)arg;
    while (1) {
        sem_wait(&full); // 等待满位
        sem_wait(&cmutex); // 加锁

        // 消费产品
        int consumed_product = buffer[out];
        out = (out + 1) % BUFFER_SIZE;

        // 打印信息
        printf("Consumer %d consumed product %d\n", consumer_id, consumed_product);

        if ((in - out + BUFFER_SIZE) % BUFFER_SIZE == 0) {
            printf("Inventory is empty (0 products)\n");
        }

        sem_post(&cmutex); // 解锁
        sem_post(&empty); // 增加空位计数

        printf("\n");

        // 休眠3秒
        sleep(4);
    }
}

void *timer(void *arg) {
    sleep(EXECUTION_TIME); // 休眠指定的时间
    printf("Execution time of %d seconds has elapsed. Terminating...\n", EXECUTION_TIME);
    exit(0); // 终止程序
}

int main() {
    pthread_t producers[NUM_PRODUCERS], consumers[NUM_CONSUMERS], timer_thread;;
    int producer_ids[NUM_PRODUCERS], consumer_ids[NUM_CONSUMERS];

    // 初始化信号量
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&pmutex, 0, 1);
    sem_init(&cmutex, 0, 1);

    // 创建生产者线程
    for (int i = 0; i < NUM_PRODUCERS; ++i) {
        producer_ids[i] = i + 1;
        pthread_create(&producers[i], NULL, producer, &producer_ids[i]);
    }

    // 创建消费者线程
    for (int i = 0; i < NUM_CONSUMERS; ++i) {
        consumer_ids[i] = i + 1;
        pthread_create(&consumers[i], NULL, consumer, &consumer_ids[i]);
    }

// 创建定时器线程
    pthread_create(&timer_thread, NULL, timer, NULL);

    // 等待所有线程结束
    for (int i = 0; i < NUM_PRODUCERS; ++i) {
        pthread_join(producers[i], NULL);
    }
    for (int i = 0; i < NUM_CONSUMERS; ++i) {
        pthread_join(consumers[i], NULL);
    }
    pthread_join(timer_thread, NULL);


    // 销毁信号量
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&pmutex);
    sem_destroy(&cmutex);

    return 0;
}
