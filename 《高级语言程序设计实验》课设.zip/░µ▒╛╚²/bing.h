#pragma once
#ifndef bing
#define bing
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
using namespace std;

double ChengBen(double pl[]);
double DanJia(double pl[]);
double JiaGe(string p, double s, double sum);
double JiaGe(string p, double s, double pl[]);

class Bing
{
public:
	double peiliao[13];
	double NUM;
	double chengben;
	double jiage;
	Bing(double a = 0, double b = 0, double c = 0, double d = 0, double e = 0, double f = 0, double g = 0, double h = 0, double i = 0, double j = 0, double k = 0, double l = 0, double m = 0)
	{
		peiliao[0] = a;
		peiliao[1] = b;
		peiliao[2] = c;
		peiliao[3] = d;
		peiliao[4] = e;
		peiliao[5] = f;
		peiliao[6] = g;
		peiliao[7] = h;
		peiliao[8] = i;
		peiliao[9] = j;
		peiliao[10] = k;
		peiliao[11] = l;
		peiliao[12] = m;
	}

	virtual void setCB()
	{
		chengben = ChengBen(peiliao);
	}
	virtual double getJG()
	{
		jiage = DanJia(peiliao);
		return jiage;
	}

	friend class Custom;
	friend class Bill;
};

class BingA :public Bing
{
public:
	double peiliao[13];
	double NUM;
	double chengben;
	double jiage;

	BingA(double a = 1, double b = 1, double c = 1, double d = 0, double e = 0, double f = 1, double g = 0, double h = 1, double i = 0, double j = 1, double k = 1, double l = 0, double m = 0)
	{
		peiliao[0] = a;
		peiliao[1] = b;
		peiliao[2] = c;
		peiliao[3] = d;
		peiliao[4] = e;
		peiliao[5] = f;
		peiliao[6] = g;
		peiliao[7] = h;
		peiliao[8] = i;
		peiliao[9] = j;
		peiliao[10] = k;
		peiliao[11] = l;
		peiliao[12] = m;
	}

	virtual void setCB()
	{
		chengben = ChengBen(peiliao);
	}

	virtual double getJG()
	{
		jiage = DanJia(peiliao);
		return jiage;
	}

	friend class Custom;
	friend class Bill;
};

class BingB :public Bing
{
public:
	double peiliao[13];
	double NUM;
	double chengben;
	double jiage;

	BingB(double a = 1, double b = 1, double c = 1, double d = 1, double e = 0, double f = 1, double g = 1, double h = 1, double i = 0, double j = 1, double k = 1, double l = 1, double m = 0)
	{
		peiliao[0] = a;
		peiliao[1] = b;
		peiliao[2] = c;
		peiliao[3] = d;
		peiliao[4] = e;
		peiliao[5] = f;
		peiliao[6] = g;
		peiliao[7] = h;
		peiliao[8] = i;
		peiliao[9] = j;
		peiliao[10] = k;
		peiliao[11] = l;
		peiliao[12] = m;
	}

	virtual void setCB()
	{
		chengben = ChengBen(peiliao);
	}

	virtual double getJG()
	{
		jiage = DanJia(peiliao);
		return jiage;
	}

	friend class Custom;
	friend class Bill;
};

class BingC :public Bing
{
public:
	double peiliao[13];
	double NUM;
	double chengben;
	double jiage;

	BingC(double a = 1, double b = 1, double c = 1, double d = 0, double e = 1, double f = 1, double g = 0, double h = 1, double i = 1, double j = 1, double k = 1, double l = 0, double m = 1)
	{
		peiliao[0] = a;
		peiliao[1] = b;
		peiliao[2] = c;
		peiliao[3] = d;
		peiliao[4] = e;
		peiliao[5] = f;
		peiliao[6] = g;
		peiliao[7] = h;
		peiliao[8] = i;
		peiliao[9] = j;
		peiliao[10] = k;
		peiliao[11] = l;
		peiliao[12] = m;
	}

	virtual void setCB()
	{
		chengben = ChengBen(peiliao);
	}

	virtual double getJG()
	{
		jiage = DanJia(peiliao);
		return jiage;
	}

	friend class Custom;
	friend class Bill;
};

#endif  