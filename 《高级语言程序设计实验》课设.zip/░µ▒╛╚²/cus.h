#pragma once
#ifndef cus
#define cus

#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
using namespace std;
#include"bing.h"
#include"accountlist.h"

class Custom
{
public:

	int h;
	string id;
	string name;
	Bing* record;
	double SUM;

	Custom(string ID = "0", string Name = "0", double s = 0.0) :
		SUM(s)
	{
		id = ID; name = Name;
	}
	string getAcntNo()
	{
		return id;
	}
	void setname(string yn)
	{
		name = yn;
	}
	string getname()
	{
		return name;
	}
	double getSUM()
	{
		return SUM;
	}
	bool operator==(const Custom& c)
	{
		return id == c.id;
	}
	void setCustom(string ID = "0", string Name = "0", double s = 0.0) 	
	{
		id = ID; name = Name; SUM = s;
	}

	friend class Bill;
};

#endif  