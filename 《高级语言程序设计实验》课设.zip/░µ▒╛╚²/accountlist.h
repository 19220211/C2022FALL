#ifndef ACCOUNTLIST
#define ACCOUNTLIST
#include"cus.h"
//-------------------------------------
class Node
{
public:
	Custom& acnt;
	Node *next, *prev;						
	Node(Custom& a) :acnt(a), next(0), prev(0)
	{}
	/*bool operator==(const Node& n)const
	{
		return acnt == n.acnt;
	}*/
};
//-----------------------------------
class AccountList
{
	int size;
	Node *first;
public:
	AccountList() :first(0), size(0)
	{}
	Node* getFirst()const
	{
		return first;
	}
	int getSize()const
	{
		return size;
	}
	void add(Custom& a);
	void remove(string acntNo);
	Custom* find(string acntNo)const;
	bool isEmpty()const
	{
		return !size;
	}
	void display()const;
	~AccountList();
};
#endif  									
