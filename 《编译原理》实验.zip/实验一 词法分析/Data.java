package cifa;

public class Data {
    private int type;
    private String value;
    private boolean isGlobal; // 新增字段，标识是否为全局变量
    
    public Data(int _type, String _value, boolean _isGlobal) {
        type = _type;
        value = _value;
        isGlobal = _isGlobal;
    }
    
    public Data(int _type, String _value) {
        this(_type, _value, false); // 默认不是全局变量
    }
    
    public Data(int _type) {
        this(_type, null, false);
    }
    
    // 新增getter方法
    public boolean isGlobal() {
        return isGlobal;
    }
    
    // 原有getter方法保持不变
    public int getType() {
        return type;
    }
    
    public String getValue() {
        return value;
    }
}