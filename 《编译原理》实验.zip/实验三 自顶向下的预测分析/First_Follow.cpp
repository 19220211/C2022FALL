#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <set>
#include <stack>
using namespace std;

void GetssFirstSet(const vector<int>& ss, int sspos);

//size of FirstSets
int FirstSetsSize;
//Rule
struct Rule
{
	int VN;
	vector<int> ss;
	int sspos; // position of ss in first sets.
};
//Grammer
vector<Rule*> grammer;
//VN List
vector<char> VNList;
//VT List
vector<char> VTList;
//First Structure
struct FirstSet
{
	vector<int> ss;
	bool flag; // if the ss has Got it First Set
	set<int> first;
};
//First Sets
vector<FirstSet*> FirstSets;
//Follow Structure, it is only to align with FirstSet, In fact we don't need create structure FollowSet.
struct FollowSet
{
	int VN;
	set<int> follow;
};
//Follow Sets
vector<FollowSet*> FollowSets;
//Follow Copy Struct
struct FollowCopy // VNlarge's follow set contains VNsmall's follow set
{
	int VNsmall;
	int VNlarge;
};
//Follow Copy Table: used in step 2 when getting follow set,
vector<FollowCopy*> FollowCopies;
//Analysis Table
vector<vector<int>* > AnalysisTable;

//print a rule
void PrintRule(const Rule* rule)
{
	cout << VNList[rule->VN - 100] << "::=";
	if (rule->ss.size() == 0)
		cout << '@';
	else
		for (size_t j = 0; j < rule->ss.size(); j++)
		{
			if (rule->ss[j] >= 100)
				cout << VNList[rule->ss[j] - 100];
			else
				cout << VTList[rule->ss[j]];
		}
}
//print grammer
void PrintGrammer()
{
	cout << "Grammer:\n";
	for (size_t i = 0; i < grammer.size(); i++)
	{
		PrintRule(grammer[i]);
		cout << endl;
	}
}
//Find a charactor from Vector<char>
int FindInVector(const vector<char>& v, char c)
{
	for (size_t i = 0; i < v.size(); i++)
	{
		if (v[i] == c)
			return i;
	}
	return -1;
}
//Analyse one VN or one VT
int FindInList(vector<char>& v, char c)
{
	int pos = FindInVector(v, c);
	if (pos == -1)
	{
		v.push_back(c);
		pos = v.size() - 1;
	}
	return pos;
}
//Analyse one Rule
void AnalyseRule(const string& rule)
{
	int VNpos = FindInList(VNList, rule[0]) + 100;
	//deal with '|'
	size_t pos = 4, prevOR = 4; // start of right part 
	vector<string> ss; // a rule can have many right parts
	while (true)
	{
		size_t pos = rule.find('|', prevOR);
		if (pos == string::npos)
		{
			ss.push_back(rule.substr(prevOR, rule.size() - prevOR));
			break;
		}
		else
		{
			ss.push_back(rule.substr(prevOR, pos - prevOR));
			prevOR = pos + 1;
		}
	}
	//construct rule and add to grammer
	for (size_t i = 0; i < ss.size(); i++) // Change 'int' to 'size_t'
	{
		string s = ss[i];
		Rule* pRule = new Rule;
		pRule->VN = VNpos;
		if (s != "@")
			for (size_t j = 0; j < s.size(); j++) // Change 'int' to 'size_t'
			{

				if (s[j] >= 'A' && s[j] <= 'Z') // is VN
					pos = FindInList(VNList, s[j]) + 100; // ID of VN is the pos in vector adding 100, distinguish with VT 
				else
					pos = FindInList(VTList, s[j]);
				pRule->ss.push_back(static_cast<int>(pos)); // Explicitly cast 'size_t' to 'int'
			}
		grammer.push_back(pRule);
	}
}
//If one Rule is valid
bool IsValidRule(const string& rule)
{
	if (rule.size() < 5 || rule[0] < 'A' || rule[0] > 'Z' || rule[rule.size() - 1] == '|' || rule.find("||", 0) != string::npos || rule.substr(1, 3) != "::=")
		return false; // if length<5 or first character is not VN or the last character is '|' or
	// rule contains "||" or rule[1...3] is not ::=, then the rule is not valid
	return true;
}
//insert s2's items into s1
void SetUnion1(set<int>& s1, set<int>& s2) //can't use const???
{
	set<int>::iterator it;
	for (it = s2.begin(); it != s2.end(); it++)
		s1.insert(*it);
}
//Add an Item To First Sets
int AddItemToFirstSets(const vector<int>& ss)
{
	size_t i; // Declare 'i' here so it is accessible outside the for loop
	for (i = 0; i < FirstSets.size(); i++)
	{
		if (FirstSets[i]->ss == ss)
			break;
	}
	if (i == FirstSets.size())
	{
		FirstSet* pFirstSet = new FirstSet;
		pFirstSet->flag = false;
		pFirstSet->ss = ss;
		FirstSets.push_back(pFirstSet);
	}
	return static_cast<int>(i); // Explicitly cast 'size_t' to 'int'
}
//init the first sets:prepare
void InitFirstSets()
{
	//who need to get first set:VN and every rule's right part
	//add VN to first sets
	for (size_t i = 0; i < VNList.size(); i++)
	{
		FirstSet* pFirstSet = new FirstSet;
		pFirstSet->flag = false;
		pFirstSet->ss.push_back(100 + static_cast<int>(i)); // Explicitly cast 'size_t' to 'int'
		FirstSets.push_back(pFirstSet);
	}
	//add every rule's right part to first sets
	for (size_t i = 0; i < grammer.size(); i++)
	{
		if (grammer[i]->ss.size() != 0) //not null
			grammer[i]->sspos = AddItemToFirstSets(grammer[i]->ss);
	}
}
//Get All VN's First Set
void GetVNFirstSet(int vn, int vnpos)
{
	if (FirstSets[vnpos]->flag == true)
		return;
	for (size_t i = 0; i < grammer.size(); i++) //for every rule
	{
		if (grammer[i]->VN == vn) //find a rule start with vn
		{
			if (grammer[i]->ss.size() == 0) //is null
				FirstSets[vnpos]->first.insert(-1); //-1 represents null,@
			else //vn's firstset contains vn's right part's first set
			{
				int sspos = grammer[i]->sspos;
				GetssFirstSet(FirstSets[sspos]->ss, sspos);
				//add ss's first set into vn's first set
				SetUnion1(FirstSets[vnpos]->first, FirstSets[sspos]->first);
			}
		}
	}
	FirstSets[vnpos]->flag = true;
}
//Get All ss's First Set
void GetssFirstSet(const vector<int>& ss, int sspos)
{
	if (FirstSets[sspos]->flag == true)
		return;
	for (size_t i = 0; i < ss.size(); i++) //for each character in ss
	{
		if (ss[i] < 100) //is VT
		{
			FirstSets[sspos]->first.insert(ss[i]);
			FirstSets[sspos]->flag = true;
			return;
		}
		else //is VN
		{
			int vnpos = ss[i] - 100;
			GetVNFirstSet(ss[i], vnpos);
			SetUnion1(FirstSets[sspos]->first, FirstSets[vnpos]->first);
			if (FirstSets[vnpos]->first.find(-1) == FirstSets[vnpos]->first.end()) //not contain null,@
			{
				FirstSets[sspos]->flag = true;
				return;
			}
		}
	}
	FirstSets[sspos]->first.insert(-1);
	FirstSets[sspos]->flag = true;
}
//Get All VN's or ss's First Set
void GetAllFirstSets()
{
	//get VN's First Set
	for (size_t i = 0; i < VNList.size(); i++)
		GetVNFirstSet(i + 100, static_cast<int>(i)); // Explicitly cast 'size_t' to 'int'
	//get ss's First Set
	for (size_t i = VNList.size(); i < FirstSets.size(); i++)
		GetssFirstSet(FirstSets[i]->ss, static_cast<int>(i)); // Explicitly cast 'size_t' to 'int'
	FirstSetsSize = static_cast<int>(FirstSets.size()); // Explicitly cast 'size_t' to 'int'
}
//Print First Set
void PrintFirstSet(FirstSet* pFirstSet)
{
	cout << "First (";
	for (size_t i = 0; i < pFirstSet->ss.size(); i++)
	{
		if (pFirstSet->ss[i] >= 100)
			cout << VNList[pFirstSet->ss[i] - 100];
		else
			cout << VTList[pFirstSet->ss[i]];
	}
	cout << ")	= { ";
	set<int>::iterator it;
	for (it = pFirstSet->first.begin(); it != pFirstSet->first.end();)
	{
		if (*it == -1)
			cout << "@";
		else
			cout << VTList[*it];
		it++;
		if (it != pFirstSet->first.end())
			cout << " ,";
	}
	cout << " }" << endl;
}
//Print First Sets
void PrintFirstSets()
{
	cout << "\nFirst Sets:\n";
	for (size_t i = 0; i < FirstSetsSize; i++)
		PrintFirstSet(FirstSets[i]);
}
//insert s2's items into s1, first set -> follow set
void SetUnion2(set<int>& s1, set<int>& s2) //can't use const???
{
	set<int>::iterator it;
	for (it = s2.begin(); it != s2.end(); it++)
	{
		if (*it != -1)
			s1.insert(*it);
	}
}
//init the follow sets:prepare
void InitFollowSets()
{
	for (size_t i = 0; i < VNList.size(); i++)
	{
		FollowSet* pFollowSet = new FollowSet;
		pFollowSet->VN = i + 100;
		FollowSets.push_back(pFollowSet);
	}
}
// Judge, if Follow Copy Table has given item
bool ExistFollowCopyItem(int VNsmall, int VNlarge)
{
	for (size_t i = 0; i < FollowCopies.size(); i++)
	{
		if (FollowCopies[i]->VNsmall == VNsmall && FollowCopies[i]->VNlarge == VNlarge)
			return true;
	}
	return false;
}
//Add an Item To Follow Copy Table
void AddItemToFollowCopies(int VNsmall, int VNlarge)
{
	if (VNsmall != VNlarge && !ExistFollowCopyItem(VNsmall, VNlarge))
	{
		FollowCopy* pFollowCopy = new FollowCopy;
		pFollowCopy->VNsmall = VNsmall;
		pFollowCopy->VNlarge = VNlarge;
		FollowCopies.push_back(pFollowCopy);
	}
}
//Get information from a Rule
void GetRuleFollowInf(const Rule* rule)
{
	if (rule->ss.size() == 0) //is null
		return;
	//
	vector<int> ss(rule->ss);
	for (size_t i = 0; i < ss.size(); i++)
	{
		//search for VN
		if (ss[i] >= 100) //is VN
		{
			if (i + 1 == ss.size()) //this VN is the last character
				AddItemToFollowCopies(rule->VN, ss[i]); //add an item into Follow Copy Table, of course the item is not existed in Follow Copy Table
			else
			{
				vector<int> sspart; //part of ss
				for (size_t j = i + 1; j < ss.size(); j++)
					sspart.push_back(ss[j]);
				//
				int sspos = AddItemToFirstSets(sspart);
				GetssFirstSet(sspart, sspos);
				SetUnion2(FollowSets[ss[i] - 100]->follow, FirstSets[sspos]->first);
				if (FirstSets[sspos]->first.find(-1) != FirstSets[sspos]->first.end()) //has @,null
					AddItemToFollowCopies(rule->VN, ss[i]);
			}
		}
	}
}
//Judge: if s2 is the subset of s1
bool IsSubSet(set<int>& s1, set<int>& s2)
{
	set<int>::iterator it;
	for (it = s2.begin(); it != s2.end(); it++)
	{
		if (s1.find(*it) == s1.end())
			return false;
	}
	return true;
}
//Use an item of Follow Copy Table
bool UseFollowCopy(FollowCopy* pFollowCopy)
{
	bool flag = false;
	if (!IsSubSet(FollowSets[pFollowCopy->VNlarge - 100]->follow, FollowSets[pFollowCopy->VNsmall - 100]->follow))
	{
		flag = true;
		SetUnion1(FollowSets[pFollowCopy->VNlarge - 100]->follow, FollowSets[pFollowCopy->VNsmall - 100]->follow);
	}
	return flag;

}
//Use Follow Copy Table, return value: if we should Use Follow Copy Table once again,
bool UseFollowCopies()
{
	bool flag = false;
	for (size_t i = 0; i < FollowCopies.size(); i++)
	{
		if (UseFollowCopy(FollowCopies[i]))
			flag = true;
	}
	return flag;
}
//Get all VN's follow sets
void GetAllFollowSets()
{
	FollowSets[0]->follow.insert(VTList.size()); //VTList.size() represents '#'(see # as a VT),'#'is the end character of a test string
	//Get information from each rule
	for (size_t i = 0; i < grammer.size(); i++)
		GetRuleFollowInf(grammer[i]);
	//Use Follow Copy Table to form each's VN's follow set until every follow set is maximum(can't add a VT to it)
	while (UseFollowCopies());
}
//Print Follow Set
void PrintFollowSet(FollowSet* pFollowSet)
{
	cout << "follow (" << VNList[pFollowSet->VN - 100];
	cout << ")	= { ";
	set<int>::iterator it;
	for (it = pFollowSet->follow.begin(); it != pFollowSet->follow.end();)
	{
		if (*it == VTList.size())
			cout << '#';
		else
			cout << VTList[*it];
		it++;
		if (it != pFollowSet->follow.end())
			cout << " ,";
	}
	cout << " }" << endl;
}
//Print Follow Sets
void PrintFollowSets()
{
	cout << "\nFollow Sets:\n";
	for (size_t i = 0; i < FollowSets.size(); i++)
		PrintFollowSet(FollowSets[i]);
}
//Print Follow Copy Table
void PrintFollowCopies()
{
	cout << "\nFollow Copy Table:\n";
	for (size_t i = 0; i < FollowCopies.size(); i++)
		cout << VNList[FollowCopies[i]->VNsmall - 100] << "	" << VNList[FollowCopies[i]->VNlarge - 100] << endl;
}
//Init the Analysis Table
void InitAnalysisTable()
{
	VTList.push_back('#');
	int colnum = VTList.size();
	for (size_t i = 0; i < VNList.size(); i++)
		AnalysisTable.push_back(new vector<int>(colnum, -1)); //colnum's -1
}
//Create the Analysis Table
void CreatAnalysisTable()
{
	for (size_t i = 0; i < grammer.size(); i++)
	{
		int vnpos = grammer[i]->VN - 100;
		set<int>::iterator it;
		set<int> first;
		//consider each rule's right part's(of course rule is not null) first set
		if (grammer[i]->ss.size() != 0)
		{
			first = FirstSets[grammer[i]->sspos]->first;
			for (it = first.begin(); it != first.end(); it++)
			{
				if (*it != -1) //rule is not @,null 
					(*AnalysisTable[vnpos])[*it] = static_cast<int>(i); // Explicitly cast 'size_t' to 'int'
			}
		}
		//consider rule's VN's follow set, if the rule's first set contains null or the rule is null itself like E::=@
		if (grammer[i]->ss.size() == 0 || first.find(-1) != first.end())
		{
			set<int> follow = FollowSets[vnpos]->follow;
			for (it = follow.begin(); it != follow.end(); it++)
				(*AnalysisTable[vnpos])[*it] = static_cast<int>(i); // Explicitly cast 'size_t' to 'int'
		}

		//PrintRule(grammer[i]); // Remove '&' before grammer[i]
		cout << endl;
	}
}
//Print the Analysis Table
void PrintAnalysisTable()
{
	//Head of Table
	cout << "\nPredictive Analysis Table:\n	";
	for (size_t i = 0; i < VTList.size(); i++)
		cout << VTList[i] << '	';
	//cout << '#' << endl;
	cout <<  endl;
	//Rows of Table
	for (size_t i = 0; i < AnalysisTable.size(); i++)
	{
		cout << VNList[i] << '	';
		for (size_t j = 0; j < (*AnalysisTable[i]).size(); j++)
		{
			if ((*AnalysisTable[i])[j] != -1)
				PrintRule(grammer[(*AnalysisTable[i])[j]]); // Remove '&' before grammer[i]
			cout << '	';
		}
		cout << endl;
	}
}
void PrintError(size_t p, const string& s)
{
	cout << "Failure:position " << p << " " << s << endl;
}
//Identify Input String


bool IdentifyString()
{
	cout << "\nInput a string to identify(input only one '#'to exit):\n";
	string s;
	cin >> s;
	if (s.size() == 1 && s[0] == '#')
		return false;
	//prepare identifying
	//s="if(exp){sensenif(exp)senelseif(exp){sensen}elseif(exp){senif(exp){if(exp){}elsesen}elseif(exp){sen}elsesen}}else{if(exp){senif(exp)senelseif(exp){sen}}}";
	s = s + "#";
	stack<int> mystack;
	mystack.push(VTList.size() - 1); //push #
	mystack.push(grammer[0]->VN); //push start character
	size_t p = 0; //pointer // Change 'int' to 'size_t'
	//begin to identify
	vector<int> derivation; // ��������¼�Ƶ�����
	while (true)
	{
		int x = mystack.top();
		if (x < 100) //is VT
		{
			if (VTList[x] != s[p])
			{
				PrintError(p, "not match");
				return true;
			}
			if (s[p] == '#')
			{
				cout << "Success!\n";
				return true;
			}
			mystack.pop();
			p++;
		}
		else //is VN
		{
			int vt = FindInVector(VTList, s[p]);
			if (vt == -1)
			{
				PrintError(p, "have unknown character");
				return true;
			}
			int ruleid = (*AnalysisTable[x - 100])[vt];
			if (ruleid == -1)
			{
				PrintError(p, "have no rule");
				return true;
			}
			derivation.push_back(ruleid); // ��¼��ǰʹ�õĹ���
			mystack.pop();
			PrintRule(grammer[ruleid]); // Remove '&' before grammer[i]
			cout << endl;
			int ss_size = static_cast<int>(grammer[ruleid]->ss.size());
			for (int i = ss_size - 1; i >= 0; i--) {
				mystack.push(grammer[ruleid]->ss[i]);
			}
		}
	}

	// �ɹ�ʱ����Ƶ�����
	cout << "Derivation steps:\n";
	for (size_t i = 0; i < derivation.size(); ++i) {
		cout << "Step " << i + 1 << ": ";
		PrintRule(grammer[derivation[i]]);
		cout << endl;
	}
	// ... 

}
int main()
{
	//Step1:Construct Grammer
	ifstream is("grammar.txt");
	while (!is.eof())
	{
		string rule;
		is >> rule;
		if (IsValidRule(rule))
			AnalyseRule(rule);
		//else
			//cout << "Rule:" << rule << " is invalid!it will be ignored!\n";
	}
	//PrintGrammer();
	//Step2:First Set
	InitFirstSets();
	GetAllFirstSets();
	PrintFirstSets();
	//Step3:Follow Set
	InitFollowSets();
	GetAllFollowSets();
	PrintFollowSets();//PrintFollowCopies();
	//Step4:Predictive Analysis Table
	InitAnalysisTable();
	CreatAnalysisTable();
	PrintAnalysisTable();
	//Step5:Identify Input String
	while (IdentifyString());
	return 0;
}

