using namespace std;
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <boost/multiprecision/cpp_int.hpp> // ������
#include <boost/multiprecision/random.hpp>   // �������
#include <boost/multiprecision/miller_rabin.hpp> // ���Լ��
#include <boost/algorithm/string.hpp>       // split()�ӿھ����������
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

namespace br = boost::random;
namespace bm = boost::multiprecision;

#define NUMBER 128 // ��ʱ��������С
#define SECRET_KEY_PATH "C:\\Users\\Lenovo\\Desktop\\secret_key.txt" // �洢N,D,E���ļ���
#define SIZE 128 // �����������С, ��Χ�� 0 ~ 1 << SIZE

typedef struct {
    bm::uint1024_t m_ekey; // ��Կe
    bm::uint1024_t m_dkey; // ˽Կd
    bm::uint1024_t m_nkey; // ����ģ��n
} Key;

class RSA {
    Key m_key;
    bm::uint1024_t GetPrime();
    bool isPrime(bm::uint1024_t& num);
    bm::uint1024_t getNkey(bm::uint1024_t& prime1, bm::uint1024_t& prime2); // ��ȡ����ģ��n
    bm::uint1024_t getOrla(bm::uint1024_t& prime1, bm::uint1024_t& prime2); // ŷ������, �õ�f(n)
    bm::uint1024_t getEkey(bm::uint1024_t& orla); // ��ȡ��Կ
    bm::uint1024_t getDkey(bm::uint1024_t& ekey, bm::uint1024_t& orla); // ��ȡ˽Կ
    void exGcd(bm::uint1024_t a, bm::uint1024_t b, bm::uint1024_t* x, bm::uint1024_t* y); // ��ģ��Ԫ��
    bm::uint1024_t getGcd(bm::uint1024_t num1, bm::uint1024_t num2); // ���Լ��
    bm::uint1024_t _encrypt(bm::uint1024_t data, bm::uint1024_t ekey, bm::uint1024_t nkey); // ����,��Ҫ�������ݺ͹�Կ(e, n)
    bm::uint1024_t _decrypt(bm::uint1024_t data, bm::uint1024_t dkey, bm::uint1024_t nkey); // ����,��ҪҪ���ܵ����ݺ�˽Կ(d, n)
    void getKeys();

public:
    RSA();
    bool encrypt(const std::string filename, const std::string outname); // ����
    bool decrypt(const std::string filename, const std::string outname); // ����
};

RSA::RSA() {
    getKeys();
}

bm::uint1024_t RSA::getNkey(bm::uint1024_t& prime1, bm::uint1024_t& prime2) {
    return prime1 * prime2;
}

bm::uint1024_t RSA::getOrla(bm::uint1024_t& prime1, bm::uint1024_t& prime2) { // prime1��prime2���뻥��
    return (prime1 - 1) * (prime2 - 1);
}

bm::uint1024_t RSA::getEkey(bm::uint1024_t& orla) {
    bm::uint1024_t ekey;
    br::mt11213b gen((size_t)time(0));
    br::uniform_int_distribution<bm::uint1024_t> dist(bm::uint1024_t(0), (bm::uint1024_t(orla)));
    do {
        ekey = dist(gen);
    } while (ekey < 2 || getGcd(ekey, orla) != 1);
    return ekey;
}

bm::uint1024_t RSA::getDkey(bm::uint1024_t& ekey, bm::uint1024_t& orla) {
    bm::uint1024_t x, y;
    exGcd(ekey, orla, &x, &y);
    return (x % orla + orla) % orla; // �任, �ý�����Կ��һ���Ƚ�С����
}

bm::uint1024_t RSA::getGcd(bm::uint1024_t num1, bm::uint1024_t num2) {
    bm::uint1024_t num;
    while ((num = num1 % num2)) {
        num1 = num2;
        num2 = num;
    }
    return num2;
}

void RSA::exGcd(bm::uint1024_t a, bm::uint1024_t b, bm::uint1024_t* x, bm::uint1024_t* y) {
    if (b == 0) {
        *x = 1;
        *y = 0;
        return;
    }
    exGcd(b, a % b, x, y);
    bm::uint1024_t tmp = *x;
    *x = *y;
    *y = tmp - a / b * (*y);
}

bm::uint1024_t RSA::_encrypt(bm::uint1024_t Ai, bm::uint1024_t ekey, bm::uint1024_t nkey) {
    // data^ekey % nkey
    // ֻ��ekey��λ���й�
    bm::uint1024_t res = 1;
    for (; ekey; ekey >>= 1) {
        if (ekey & 1) {
            res = (res * Ai) % nkey;
        }
        Ai = (Ai * Ai) % nkey;
    }
    return res;
}

bm::uint1024_t RSA::_decrypt(bm::uint1024_t data, bm::uint1024_t dkey, bm::uint1024_t nkey) {
    return _encrypt(data, dkey, nkey);
}

bool RSA::isPrime(bm::uint1024_t& num) {
    br::mt11213b gen((size_t)time(0)); // Ҫ�Ͳ���������ķ�������һ��
    if (miller_rabin_test(num, 25, gen)) {
        if (miller_rabin_test((num - 1) / 2, 25, gen)) {
            return true;
        }
    }
    return false;
}

bm::uint1024_t RSA::GetPrime() {
    bm::uint1024_t res;
    br::mt19937 gen((size_t)time(0));
    br::uniform_int_distribution<bm::uint1024_t> dist(bm::uint1024_t(0), (bm::uint1024_t(1) << SIZE));
    while (!isPrime(res = dist(gen)));
    return res;
}

void RSA::getKeys() {
    FILE* fp;
    errno_t err = fopen_s(&fp, SECRET_KEY_PATH, "r");
    if (err != 0) {
        cout << "������Կ, ��Կ��...\n";
        bm::uint1024_t prime1, prime2 = GetPrime();
        while ((prime1 = GetPrime()) == prime2);
        m_key.m_nkey = getNkey(prime1, prime2);
        bm::uint1024_t orla = getOrla(prime1, prime2);
        m_key.m_ekey = getEkey(orla);
        m_key.m_dkey = getDkey(m_key.m_ekey, orla);
        stringstream tmp;
        tmp << m_key.m_nkey << '\n' << m_key.m_ekey << '\n' << m_key.m_dkey << '\n';
        ofstream fout(SECRET_KEY_PATH, ofstream::binary);
        if (fout.is_open() == false) {
            perror("file open failed!");
            return;
        }
        fout.write(tmp.str().c_str(), tmp.str().size());
        if (fout.good() == false) {
            cout << "file " << SECRET_KEY_PATH << " read data failed!\n";
        }
        fout.close();
    }
    else {
        fseek(fp, 0L, SEEK_END);
        size_t fsize = ftell(fp);
        fclose(fp);
        ifstream fin(SECRET_KEY_PATH, ifstream::binary);
        if (fin.is_open() == false) {
            perror("file open failed!");
            return;
        }
        string buf;
        buf.resize(fsize);
        fin.read(&buf[0], fsize);
        if (fin.good() == false) {
            cout << "file " << SECRET_KEY_PATH << " read data failed!\n";
        }
        fin.close();
        vector<string> secret_key;
        // split���ڷָ��ַ���
        boost::split(secret_key, buf, boost::is_any_of("\n"), boost::token_compress_on);
        m_key.m_nkey = bm::uint1024_t(secret_key[0]);
        m_key.m_ekey = bm::uint1024_t(secret_key[1]);
        m_key.m_dkey = bm::uint1024_t(secret_key[2]);
    }
}

bool RSA::encrypt(const string filename, const string outname) {
    ifstream fin(filename, ifstream::binary);
    ofstream fout(outname, ofstream::binary);
    if (!fin.is_open()) {
        perror("input file open failed!");
        return false;
    }
    char* buffer = new char[NUMBER];
    bm::uint1024_t* bufferOut = new bm::uint1024_t[NUMBER];
    while (fin) {
        fin.read(buffer, NUMBER);
        streamsize ret = fin.gcount();
        for (streamsize i = 0; i < ret; ++i) {
            bufferOut[i] = _encrypt(static_cast<unsigned char>(buffer[i]), m_key.m_ekey, m_key.m_nkey);
        }
        fout.write(reinterpret_cast<char*>(bufferOut), ret * sizeof(bm::uint1024_t));
    }
    delete[] bufferOut;
    delete[] buffer;
    fin.close();
    fout.close();
    return true;
}

bool RSA::decrypt(const string filename, const string outname) {
    ifstream fin(filename, ifstream::binary);
    ofstream fout(outname, ofstream::binary);
    if (!fin.is_open()) {
        perror("file open failed");
        return false;
    }
    bm::uint1024_t* buffer = new bm::uint1024_t[NUMBER];
    char* bufferOut = new char[NUMBER];
    while (fin) {
        fin.read(reinterpret_cast<char*>(buffer), NUMBER * sizeof(bm::uint1024_t));
        streamsize ret = fin.gcount() / sizeof(bm::uint1024_t);
        for (streamsize i = 0; i < ret; ++i) {
            bufferOut[i] = static_cast<char>(_decrypt(buffer[i], m_key.m_dkey, m_key.m_nkey));
        }
        fout.write(bufferOut, ret);
    }
    delete[] bufferOut;
    delete[] buffer;
    fin.close();
    fout.close();
    return true;
}

void Test(const string filename, const string EncName, const string DecName) {
    RSA rsa;
    if (rsa.encrypt(filename, EncName)) {
        cout << "�������!\n";
        if (rsa.decrypt(EncName, DecName)) {
            cout << "�������!";
        }
    }
    cout << "3�������˳�!\n";
    Sleep(3000); // ��Linux��Ϊsleep(3), ��Ҫ����ͷ�ļ� unistd.h
}

int main() {
    string filename("C:\\Users\\Lenovo\\Desktop\\����.txt"), EncName("C:\\Users\\Lenovo\\Desktop\\����.txt"), DecName("C:\\Users\\Lenovo\\Desktop\\���ܺ���ļ�.txt");
    Test(filename, EncName, DecName);
    return 0;
}


