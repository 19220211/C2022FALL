package com.nnu.EPA.controller;

import com.nnu.EPA.pojo.Album;
import com.nnu.EPA.pojo.Picture;
import com.nnu.EPA.service.PictureService;
import com.nnu.EPA.service.albumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/api/albums")
public class AlbumsController {

    @Autowired
    private albumService albumService;

    @Autowired
    private PictureService imageService;
    @GetMapping("/album/{albumId}/pictures")
    public ResponseEntity<?> getPicturesByAlbum(@PathVariable Long albumId) {
        List<Picture> pictures = imageService.findByAlbumId(albumId);
        if (pictures.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new UploadResponse(false, "相册没有图片"));
        }
        for (Picture picture : pictures) {
            picture.setFilePath("http://localhost:8080/uploads/" + picture.getFilePath());
        }
        return ResponseEntity.ok(pictures);
    }


    @PostMapping("/uploadImage")
    public ResponseEntity<?> uploadImage(@RequestParam("image") MultipartFile image,
                                         @RequestParam("albumId") Long albumId) {
        try {
            // 获取相册
            Album album = albumService.findById(albumId);
            if (album == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new UploadResponse(false, "无效的相册 ID"));
            }

            // 获取图片文件名
            String fileName = image.getOriginalFilename();
            if (fileName == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new UploadResponse(false, "文件名无效"));
            }

            // 创建上传目录
            Path uploadDir = Paths.get("uploads");
            if (Files.notExists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }

            // 设置目标路径
            Path targetLocation = uploadDir.resolve(fileName);

            // 如果文件已存在，删除旧文件（覆盖）
            if (Files.exists(targetLocation)) {
                Files.delete(targetLocation);
            }

            // 上传新文件
            Files.copy(image.getInputStream(), targetLocation);

            // 保存图片记录到数据库
            Picture newImage = new Picture();
            newImage.setAlbum(album); // 关联相册
            newImage.setPicturename(fileName); // 设置图片名称
            newImage.setFilePath(targetLocation.toString()); // 保存图片的相对路径
            imageService.save(newImage); // 保存图片到数据库

            // 返回上传成功响应
            // 上传图片时返回完整的图片路径
            String imageUrl = "/uploads/" + fileName;  // 拼接完整的 URL
            return ResponseEntity.ok().body(new UploadResponse(true, "图片上传成功", imageUrl));

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new UploadResponse(false, "图片上传失败"));
        }
    }

    // 用于返回上传响应的类
    public static class UploadResponse {
        private boolean success;
        private String message;
        private String filePath; // 返回图片路径

        public UploadResponse(boolean success, String message) {
            this(success, message, null);
        }

        public UploadResponse(boolean success, String message, String filePath) {
            this.success = success;
            this.message = message;
            this.filePath = filePath;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }
    }
}


