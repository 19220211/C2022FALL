package com.nnu.EPA.service;

public class loginService {
    public String handleForgotPassword(String username, String email, String phone) {

        return "1";
    }
}
