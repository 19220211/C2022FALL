package com.nnu.EPA.pojo;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_album")
public class Album {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 主键自动增长
    private Long albumID;

    @Column(name = "albumname", length = 40, nullable = false)
    private String albumname;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted;

    @ManyToOne(fetch = FetchType.EAGER)  // 修改为 EAGER
    @JoinColumn(name = "id", referencedColumnName = "id", nullable = false)
    private User user;

    // Getters and Setters
    public Long getAlbumID() {
        return albumID;
    }

    public void setAlbumID(Long albumID) {
        this.albumID = albumID;
    }

    public String getAlbumname() {
        return albumname;
    }

    public void setAlbumname(String albumname) {
        this.albumname = albumname;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Album{" +
                "albumID=" + albumID +
                ", albumname='" + albumname + '\'' +
                ", isDeleted=" + isDeleted +
                ", user=" + user +
                '}';
    }
}
