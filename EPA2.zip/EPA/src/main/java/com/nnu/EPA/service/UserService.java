package com.nnu.EPA.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.nnu.EPA.pojo.*;
import com.nnu.EPA.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public String registerUser(User user) {
        logger.info("Username: {}, Email: {}, Password: {}", user.getUsername(), user.getEmail(), user.getPassword());

        logger.info("Received user for registration: {}", user);
        if (userRepository.existsByUsername(user.getUsername())) {
            return "Username already exists!";
        }
        userRepository.save(user);
        logger.info("User saved successfully: {}", user);
        return "User registered successfully!";
    }
    @Transactional
    public String changePassword(String email, String newPassword) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return "用户不存在！";
        }
        user.setPassword(newPassword);
        userRepository.save(user);
        logger.info("Password changed successfully for user: {}", user);
        return "密码修改成功！";
    }
}

