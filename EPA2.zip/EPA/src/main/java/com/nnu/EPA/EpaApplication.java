package com.nnu.EPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpaApplication.class, args);
	}
}
