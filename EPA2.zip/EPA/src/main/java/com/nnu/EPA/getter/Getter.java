package com.nnu.EPA.getter;

public class Getter {
}
