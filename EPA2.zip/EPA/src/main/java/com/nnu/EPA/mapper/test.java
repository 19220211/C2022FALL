package com.nnu.EPA.mapper;
/*
该软件包又名repository，dao，数据库增删改查
 */

public class test {
}
