package com.nnu.EPA.mapper;

import com.nnu.EPA.pojo.Album;
import com.nnu.EPA.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlbumRepository extends JpaRepository<Album, String> {

        List<Album> findByUser( User user); // 根据用户查找相册

}
