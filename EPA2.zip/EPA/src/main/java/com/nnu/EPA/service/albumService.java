package com.nnu.EPA.service;

import com.nnu.EPA.pojo.Album;
import com.nnu.EPA.mapper.*;
import com.nnu.EPA.pojo.Picture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class albumService {

    public Album saveAlbum(Album album){return null;}
    public List<Album>getAllAlbums(){return null;}
    public void deleteAlbum(int id){}

    @Autowired
    private AlbumRepository albumRepository;  // 注入 AlbumRepository

    public Album findById(Long albumId) {
        return albumRepository.findById(String.valueOf(albumId)).orElse(null);
    }

}
