package com.nnu.EPA.pojo;

public class Friend {
}
