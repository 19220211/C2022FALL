package com.nnu.EPA.service;

import com.nnu.EPA.pojo.Friend;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendService {
    public void addFriend(Friend friend){}
    public List<Friend> getAllFriends(){
        return null;
    }

}
