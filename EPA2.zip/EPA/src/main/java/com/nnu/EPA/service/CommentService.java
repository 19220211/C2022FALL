package com.nnu.EPA.service;

import com.nnu.EPA.mapper.CommentRepository;
import com.nnu.EPA.mapper.PictureRepository;
import com.nnu.EPA.pojo.Comment;
import com.nnu.EPA.pojo.Picture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private PictureRepository imageRepository;

    public Comment addComment(Long imageId, Long userId, String content) {
        Picture image = imageRepository.findById(imageId)
                .orElseThrow(() -> new RuntimeException("Image not found"));

        Comment comment = new Comment();
        comment.setImage(image);
        comment.setUserId(userId);
        comment.setContent(content);

        return commentRepository.save(comment);
    }
}
