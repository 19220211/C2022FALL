package com.nnu.EPA.controller;

import com.nnu.EPA.mapper.LikeRepository;
import com.nnu.EPA.mapper.PictureRepository;
import com.nnu.EPA.pojo.Like;
import com.nnu.EPA.pojo.Picture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/likes")
public class LikeController {
    @Autowired
    private LikeRepository likeRepository;

    @Autowired
    private PictureRepository imageRepository;

    @PostMapping("/{imageId}/like")
    public String likeImage(@PathVariable Long imageId, @RequestParam Long userId) {
        Picture image = imageRepository.findById(imageId)
                .orElseThrow(() -> new RuntimeException("Image not found"));

        Like like = new Like();
        like.setImage(image);
        like.setUserId(userId);

        likeRepository.save(like);

        return "Image liked successfully";
    }
}
