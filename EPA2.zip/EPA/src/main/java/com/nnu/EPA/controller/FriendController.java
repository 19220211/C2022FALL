package com.nnu.EPA.controller;

import com.nnu.EPA.pojo.Friend;
import com.nnu.EPA.service.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
public class FriendController {

    @Autowired
    private FriendService friendService;

    @PostMapping("/add")
    public ResponseEntity<String> addFriend(@RequestBody Friend friend) {
        friendService.addFriend(friend);
        return ResponseEntity.ok("好友添加成功！");
    }

    @GetMapping("/list")
    public List<Friend> listFriends() {
        return friendService.getAllFriends();
    }
}
