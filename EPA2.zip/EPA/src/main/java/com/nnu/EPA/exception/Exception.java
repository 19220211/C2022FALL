package com.nnu.EPA.exception;

public class Exception {
}
