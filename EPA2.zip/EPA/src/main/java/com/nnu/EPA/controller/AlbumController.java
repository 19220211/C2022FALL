package com.nnu.EPA.controller;

import com.nnu.EPA.DTO.AlbumRequest;
import com.nnu.EPA.mapper.AlbumRepository;
import com.nnu.EPA.pojo.User;
import com.nnu.EPA.service.albumService;
import com.nnu.EPA.pojo.Album;
import com.nnu.EPA.mapper.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.sql.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/albums")
public class AlbumController {

    @Autowired
    private AlbumRepository albumRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/create")
    public ResponseEntity<Album> createAlbum(@RequestBody AlbumRequest request) {
        String albumTitle = request.getTitle();
        String userEmail = request.getEmail();
          System.out.println(albumTitle+"hello");

        if (albumTitle == null || userEmail == null) {
            return ResponseEntity.badRequest().body(null);
        }

        User user = userRepository.findByEmail(userEmail);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        Album album = new Album();
        album.setAlbumname(albumTitle);
        album.setUser(user);
        album.setDeleted(false);

        albumRepository.save(album);
        System.out.println("Created album: " + album);  // 打印创建的相册信息，检查是否包含正确的值
        return ResponseEntity.ok(album);
    }



    @GetMapping("/list")
    public List<Album> listAlbums(@RequestParam String userEmail) {
        User user = userRepository.findByEmail(userEmail); // 根据邮箱查找用户
        if (user == null) {
            return new ArrayList<>(); // 如果没有找到用户，返回空列表
        }
        return albumRepository.findByUser(user); // 根据用户查找相册
    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAlbum(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return ResponseEntity.badRequest().body("无效的相册 ID");
        }
        if (albumRepository.existsById(String.valueOf(id))) {
            albumRepository.deleteById(String.valueOf(id));
            return ResponseEntity.ok("相册删除成功！");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("相册未找到");
        }
    }


}

