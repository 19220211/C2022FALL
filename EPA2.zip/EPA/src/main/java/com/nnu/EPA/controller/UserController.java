package com.nnu.EPA.controller;

import com.nnu.EPA.DTO.ChangePasswordRequest;
import com.nnu.EPA.mapper.*;
import com.nnu.EPA.pojo.Forgot;
import com.nnu.EPA.pojo.User;
import com.nnu.EPA.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:8080")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    @CrossOrigin(origins = "http://localhost:63342")//便于跨域访问
    public String registerUser(@RequestBody User user) {
        return userService.registerUser(user);
    }
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User loginRequest) {
        User user = userRepository.findByEmail(loginRequest.getEmail());
        if (user != null && user.getPassword().equals(loginRequest.getPassword())) {
            return ResponseEntity.ok("登录成功！");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("邮箱或密码错误！");
    }

    @GetMapping("/register")
    public String handleGetRequest() {
        return "Please use POST method to register a user.";
    }
    @Autowired
    private forgotPasswordService forgotPasswordService;  // 注入服务类

    @PostMapping("/forgot_password")
    public ResponseEntity<String> forgotPassword(@RequestBody Forgot forgotPasswordRequest) {
        // 调用 forgotPasswordService 中的 processForgotPassword 方法
        String responseMessage = forgotPasswordService.processForgotPassword(
                forgotPasswordRequest.getUsername(),
                forgotPasswordRequest.getEmail(),
                forgotPasswordRequest.getPhone()
        );

        // 根据返回的消息决定响应状态
        if (responseMessage.equals("提交成功！请检查您的邮箱以重置密码。")) {
            return ResponseEntity.ok(responseMessage);  // 返回成功响应
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMessage);  // 返回错误响应
        }
    }
    @PostMapping("/change_password")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordRequest request) {
        String result = userService.changePassword(request.getEmail(), request.getNewPassword());
        return new ResponseEntity<>(Map.of("message", result), HttpStatus.OK);
    }
}




