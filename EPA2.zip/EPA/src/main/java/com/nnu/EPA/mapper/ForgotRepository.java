package com.nnu.EPA.mapper;

import com.nnu.EPA.pojo.Forgot;
import com.nnu.EPA.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ForgotRepository extends JpaRepository<Forgot, Long> {

    boolean existsByUsername(String username);
    Forgot findByEmail(String email);
    Optional<User> findByUsernameAndEmail(String username, String email);
}
