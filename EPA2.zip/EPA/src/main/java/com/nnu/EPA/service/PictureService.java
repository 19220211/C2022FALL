package com.nnu.EPA.service;

import com.nnu.EPA.pojo.Picture;
import com.nnu.EPA.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureService {

    @Autowired
    private PictureRepository pictureRepository;

    public Picture save(Picture picture) {
        return pictureRepository.save(picture);
    }
    public List<Picture> findByAlbumId(Long albumId) {
        return pictureRepository.findByAlbum_AlbumID(albumId);
    }
}
