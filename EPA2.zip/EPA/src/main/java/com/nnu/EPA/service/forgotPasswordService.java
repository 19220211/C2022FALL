package com.nnu.EPA.service;

import com.nnu.EPA.mapper.ForgotRepository;
import com.nnu.EPA.mapper.UserRepository;
import com.nnu.EPA.pojo.Forgot;
import com.nnu.EPA.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class forgotPasswordService {

    private static final Logger logger = LoggerFactory.getLogger(forgotPasswordService.class);

    @Autowired
    private ForgotRepository forgotRepository;

    @Autowired
    private UserRepository userRepository;  // 假设你有这个仓库，用来检查用户信息

    @Transactional
    public String processForgotPassword(String username, String email, String phone) {
        logger.info("Username: {}, Email: {}, Phone: {}", username, email, phone);

        // 验证用户是否存在
        Optional<User> user = userRepository.findByUsernameAndEmail(username, email);
        if (user.isPresent()) {
            logger.info("User found for password reset: {}", user.get());

            // 创建 Forgot 实体并保存到数据库
            Forgot forgot = new Forgot();
            forgot.setUsername(username);
            forgot.setEmail(email);
            forgot.setPhone(phone);

            forgotRepository.save(forgot);  // 将信息保存到数据库
            logger.info("Reset request saved to database: {}", forgot);

            return "数据已保存";
        } else {
            logger.warn("No matching user found for username: {} and email: {}", username, email);
            return "用户信息不匹配，请重新输入。";
        }
    }
}



