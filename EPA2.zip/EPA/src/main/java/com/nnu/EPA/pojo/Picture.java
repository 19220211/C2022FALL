package com.nnu.EPA.pojo;

import java.util.Arrays;


import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "tb_picture")
public class Picture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 主键自动增长
    private Long pictureID;

    @Column(name = "picturename", length = 40, nullable = false)
    private String picturename;

    @Column(name = "photodesc", length = 500)
    private String photodesc;

    @Column(name = "filePath")
    private String filePath;

    @Column(name = "com_times", nullable = false)
    private int comTimes;

    @Lob
    @Column(name = "picture", columnDefinition = "MEDIUMBLOB") // 图片数据
    private byte[] picture;


    @Column(name = "like_times", nullable = false)
    private int likeTimes;

    // 将fetch改为EAGER，表示立即加载关联的Album和User对象
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "albumID", referencedColumnName = "albumID", nullable = false)
    private Album album;
/*
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id", referencedColumnName = "id", nullable = false)
    private User user;*/

    // Getters and Setters
    public Long getPictureID() {
        return pictureID;
    }

    public void setPictureID(long pictureID) {
        this.pictureID = pictureID;
    }

    public String getPicturename() {
        return picturename;
    }

    public void setPicturename(String picturename) {
        this.picturename = picturename;
    }

    public String getPhotodesc() {
        return photodesc;
    }

    public void setPhotodesc(String photodesc) {
        this.photodesc = photodesc;
    }

    public int getComTimes() {
        return comTimes;
    }

    public void setComTimes(int comTimes) {
        this.comTimes = comTimes;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }


    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

 /*   public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }*/

    public int getLikeTimes() {
        return likeTimes;
    }

    public void setLikeTimes(int likeTimes) {
        this.likeTimes = likeTimes;
    }

    public void setPictureID(Long pictureID) {
        this.pictureID = pictureID;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "Picture{" +
                "pictureID='" + pictureID + '\'' +
                ", picturename='" + picturename + '\'' +
                ", photodesc='" + photodesc + '\'' +
                ", filePath='" + filePath + '\'' +
                ", comTimes=" + comTimes +
                ", picture=" + Arrays.toString(picture) +
                ", likeTimes=" + likeTimes +
                ", album=" + album +
                '}';
    }
}
