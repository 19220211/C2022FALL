package com.nnu.EPA.DTO;

    public class AlbumRequest {
        private String title; // 相册名称
        private Long userId;  // 用户 ID
        private String email;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @Override
        public String toString() {
            return "AlbumRequest{" +
                    "title='" + title + '\'' +
                    ", userId=" + userId +
                    ", email='" + email + '\'' +
                    '}';
        }
        // Getters 和 Setters
    }


