package com.nnu.EPA.pojo;
/*
该软件包又名model，entity，数据库实体
 */
public class test {
}
