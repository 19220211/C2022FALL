// 登录按钮逻辑
document.getElementById('loginBtn').addEventListener('click', async () => {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const loginMessage = document.getElementById('loginMessage');

    // 清空提示信息
    loginMessage.textContent = '';

    // 验证输入
    if (!email || !password) {
        loginMessage.textContent = '请填写所有字段！';
        return;
    }

    try {
        // 发送 POST 请求到后端登录接口
        const response = await fetch('http://localhost:8080/api/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            const result = await response.text(); // 获取后端响应内容
            loginMessage.style.color = 'green';
            loginMessage.textContent = result;
            localStorage.setItem('email', email);

            // 跳转到用户中心页面
            setTimeout(() => {
                window.location.href = 'user_center.html';
            }, 1500);
        } else {
            // 登录失败
            const errorText = await response.text();
            loginMessage.style.color = 'red';
            loginMessage.textContent = errorText || '登录失败，请检查输入！';
        }
    } catch (error) {
        // 网络错误处理
        loginMessage.style.color = 'red';
        loginMessage.textContent = '网络错误，请稍后重试！';
    }
});


