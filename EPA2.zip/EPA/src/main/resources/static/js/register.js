document.getElementById('registerBtn').addEventListener('click', async function () {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const messageElement = document.getElementById('registerMessage'); // 获取显示消息的元素

    // 检查密码和确认密码是否一致
    if (password !== confirmPassword) {
        messageElement.textContent = "密码和确认密码不一致！";
        messageElement.className = "message error"; // 错误样式
        return;
    }

    try {
        // 发送 POST 请求到后端注册接口
        const response = await fetch('http://localhost:8080/api/users/register', {
            method: 'POST', // 设置请求方法为 POST
            headers: {
                'Content-Type': 'application/json', // 设置请求体为 JSON 格式
            },
            body: JSON.stringify({ username, email, password }), // 将用户名、邮箱和密码封装为 JSON
        });

        // 判断请求是否成功
        if (response.ok) {
            const result = await response.text(); // 获取响应内容
            messageElement.textContent = result || "注册成功！";
            messageElement.className = "message success"; // 成功样式
            setTimeout(() => {
                window.location.href = 'login.html'; // 注册成功后跳转到登录页面
            }, 2000); // 等待 2 秒后跳转
        } else {
            const errorText = await response.text(); // 获取错误信息
            messageElement.textContent = errorText || "注册失败，请稍后重试。";
            messageElement.className = "message error"; // 错误样式
        }
    } catch (error) {
        // 捕获网络错误
        messageElement.textContent = "网络错误，请稍后重试。";
        messageElement.className = "message error"; // 错误样式
    }
});


