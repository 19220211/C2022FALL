// 获取图片路径参数
const urlParams = new URLSearchParams(window.location.search);
const image = decodeURIComponent(urlParams.get('image'));

const imageElement = document.getElementById('image');
let hasErrorHandled = false; // 用于标记是否已经处理过错误

// 检查图片参数是否存在
if (image) {
    imageElement.src = image;

    // 如果图片加载失败，显示错误消息并加载默认图片
    imageElement.onerror = function () {
        if (!hasErrorHandled) {
            hasErrorHandled = true; // 防止重复处理错误
            console.warn('无法加载图片，切换到默认图片...');
            imageElement.src = '../picture/OIP.jpg'; // 设置默认图片路径
        } else {
            console.error('默认图片加载失败，请检查路径是否正确！');
        }
    };
} else {
    console.warn('图片未找到，加载默认图片...');
    imageElement.src = '/photo/OIP.jpg'; // 设置默认图片路径
    imageElement.alt = '默认图片加载失败';
}

// 模拟一些点赞和评论数据
let likesCount = 3; // 模拟点赞的数量
let comments = [
    { text: "这张图片太棒了！", id: 1 },
    { text: "非常喜欢这张照片！", id: 2 }
];

// 更新点赞和评论的显示
function updateLikesAndComments() {
    document.getElementById('likes').textContent = `👍 ${likesCount} Likes`;
    document.getElementById('comments').textContent = `💬 ${comments.length} Comments`;

    const commentsSection = document.getElementById('commentsSection');
    commentsSection.innerHTML = ''; // 清空当前评论

    comments.forEach(comment => {
        const commentDiv = document.createElement('div');
        commentDiv.classList.add('comment');
        commentDiv.innerHTML = `
            <p class="text">${comment.text}</p>
            <button onclick="deleteComment(${comment.id})">删除</button>
        `;
        commentsSection.appendChild(commentDiv);
    });
}

// 点赞功能
document.getElementById('likes').addEventListener('click', function () {
    likesCount++; // 点赞数加一
    updateLikesAndComments(); // 更新点赞和评论显示
});

// 提交留言功能
function submitComment() {
    const commentText = document.getElementById('commentInput').value;
    if (commentText.trim() !== "") {
        comments.push({ text: commentText, id: Date.now() }); // 使用时间戳作为唯一 ID
        document.getElementById('commentInput').value = ''; // 清空输入框
        updateLikesAndComments(); // 更新点赞和评论显示
    }
}

// 删除评论功能
function deleteComment(commentId) {
    const confirmDelete = confirm("你确定要删除这条评论吗?");
    if (confirmDelete) {
        comments = comments.filter(comment => comment.id !== commentId); // 删除对应 ID 的评论
        updateLikesAndComments(); // 更新评论显示
    }
}

// 初始更新显示
updateLikesAndComments();
