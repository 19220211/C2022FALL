document.getElementById('submitBtn').addEventListener('click', async function () {
    // 获取表单数据
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const resetMessage = document.getElementById('resetMessage');

    // 验证是否填写了所有字段
    if (!username || !email || !phone) {
        resetMessage.textContent = '请填写所有字段';
        resetMessage.style.color = 'red';
        return;
    }

    try {
        // 发送 POST 请求到后端忘记密码接口
        const response = await fetch('http://localhost:8080/api/users/forgot_password', {
            method: 'POST', // 设置请求方法为 POST
            headers: {
                'Content-Type': 'application/json', // 设置请求体为 JSON 格式
            },
            body: JSON.stringify({ username, email, phone }), // 将用户名、邮箱和电话封装为 JSON
        });

        // 判断请求是否成功
        if (response.ok) {
            const result = await response.text(); // 获取响应内容
            resetMessage.textContent = result || "提交成功！请检查您的邮箱以重置密码。";
            resetMessage.style.color = 'green'; // 成功样式
        } else {
            const errorText = await response.text(); // 获取错误信息
            resetMessage.textContent = errorText || "提交失败，请检查输入是否有误";
            resetMessage.style.color = 'red'; // 错误样式
        }
    } catch (error) {
        // 捕获网络错误
        resetMessage.textContent = "网络错误，请稍后重试。";
        resetMessage.style.color = 'red'; // 错误样式
    }
});

