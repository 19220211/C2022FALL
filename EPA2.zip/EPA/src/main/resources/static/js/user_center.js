document.addEventListener('DOMContentLoaded', loadAlbums);
createAlbumBtn.addEventListener('click', async function () {
    const albumTitle = prompt('请输入相册标题:');
    const email = localStorage.getItem('email'); // 从 localStorage 获取邮箱

    if (!email) {
        alert('用户未登录');
        window.location.href = 'login.html';
        return;
    }

    if (albumTitle) {
        try {
            const response = await fetch('http://localhost:8080/api/albums/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    title: albumTitle,
                    email: email,
                }),
            });

            if (response.ok) {
                const album = await response.json();
                renderAlbum(album);
            } else {
                alert('创建相册失败，请稍后再试！');
            }
        } catch (error) {
            console.error('网络错误:', error);
            alert('网络错误，请稍后再试！');
        }
    }
});
async function loadAlbums() {
    const email = localStorage.getItem('email'); // 获取用户邮箱

    if (!email) {
        alert('用户未登录，请先登录！');
        window.location.href = 'login.html';
        return;
    }

    try {
        const response = await fetch(`http://localhost:8080/api/albums/list?userEmail=${email}`);
        if (response.ok) {
            const albums = await response.json();
            albums.forEach(album => renderAlbum(album));
        } else {
            console.error('无法加载相册列表');
        }
    } catch (error) {
        console.error('网络错误:', error);
    }
}
function renderAlbum(album) {
    const albumContainer = document.getElementById('albumContainer'); // 确保这个容器存在

    const albumItem = document.createElement('div');
    albumItem.classList.add('album-item');

    // 创建一个包含标题和图片的容器
    const albumContent = document.createElement('div');
    albumContent.classList.add('album-content');

    // 在图片上面添加标题
    const caption = document.createElement('div');
    caption.classList.add('caption');

    caption.innerText = album.albumname || '无标题'; // 使用默认标题文本

    const img = document.createElement('img');
    img.src = album.coverImage || '../picture/cover.png'; // 默认图片
    img.alt = album.title || '相册图片';

    // 将标题和图片放到 albumContent 中
    albumContent.appendChild(caption);
    albumContent.appendChild(img);

    // 创建一个按钮容器并放置按钮
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.justifyContent = 'space-between';
    buttonContainer.style.marginTop = '10px';

    const enterBtn = document.createElement('button');
    enterBtn.textContent = '进入';
    enterBtn.classList.add('friend-action-btn');

    // 跳转到 album.html 并传递 album.id 作为查询参数
    enterBtn.onclick = function () {
        window.location.href = `album.html?id=${album.albumID}`;
    };

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '删除';
    deleteBtn.classList.add('friend-action-btn');
    deleteBtn.onclick = async function () {
        console.log("Deleting album with ID:", album.albumID);  // 打印 ID 调试
        if (confirm('确定删除此相册吗？')) {
            try {
                const response = await fetch(`http://localhost:8080/api/albums/delete/${album.id}`, {
                    method: 'DELETE',
                });

                if (response.ok) {
                    albumContainer.removeChild(albumItem); // 删除相册
                } else {
                    alert('删除相册失败，请稍后再试！');
                }
            } catch (error) {
                console.error('网络错误:', error);
            }
        }
    };

    // 将按钮添加到按钮容器
    buttonContainer.appendChild(enterBtn);
    buttonContainer.appendChild(deleteBtn);

    // 将图片、标题、按钮容器添加到 albumItem 中
    albumItem.appendChild(albumContent);
    albumItem.appendChild(buttonContainer);

    // 最终将 albumItem 添加到容器中
    albumContainer.appendChild(albumItem);
}




