document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('addImageInput');
    if (fileInput) {
        fileInput.addEventListener('change', handleImageUpload);
    }
});

async function handleImageUpload(event) {
    const fileInput = event.target;
    const file = fileInput.files[0];

    if (!file) {
        alert('请选择一个文件');
        return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const albumId = urlParams.get('id');
    if (!albumId) {
        alert('相册 ID 不存在');
        return;
    }

    const formData = new FormData();
    formData.append('image', file);
    formData.append('albumId', albumId);

    try {
        const response = await fetch('http://localhost:8080/api/albums/uploadImage', {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();

        if (data.success) {
            const albumContainer = document.querySelector('.album-container');

            const newImage = document.createElement('div');
            newImage.classList.add('album-item');

            const img = document.createElement('img');
            img.src = data.filePath; // 使用返回的完整图片路径
            img.alt = 'New Image';
            img.classList.add('album-image');

            const imageInfo = document.createElement('div');
            imageInfo.classList.add('image-info');

            const likes = document.createElement('span');
            likes.classList.add('likes');
            likes.textContent = '👍 0';

            const comments = document.createElement('span');
            comments.classList.add('comments');
            comments.textContent = '💬 0';

            imageInfo.appendChild(likes);
            imageInfo.appendChild(comments);

            newImage.appendChild(img);
            newImage.appendChild(imageInfo);

            albumContainer.insertBefore(newImage, document.querySelector('.add-image-item'));
        }
        else {
            alert(data.message || '图片上传失败，请重试');
        }
    } catch (error) {
        console.error('图片上传失败:', error);
        alert('网络错误，请稍后再试！');
    }


}

