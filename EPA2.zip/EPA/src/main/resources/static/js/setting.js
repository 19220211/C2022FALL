function openModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
}

window.onclick = function(event) {
    var modal = document.getElementById("myModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

document.querySelector(".close").onclick = function() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}

document.getElementById("changePasswordForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var email = document.getElementById("email").value;
    var newPassword = document.getElementById("newPassword").value;

    fetch('http://localhost:8080/api/users/change_password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email: email, newPassword: newPassword })
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        })
        .catch(error => {
            console.error('Error:', error);
            alert('发生错误，请重试');
        });
});

function logout() {
    window.location.href = 'login.html';
}

function deactivateAccount() {
    alert("该用户已注销,请重新注册");
    window.location.href = 'register1.html';
}