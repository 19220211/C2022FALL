#include<iostream>
using namespace std;
struct AllocatedSpace
{
	int start_address;
	int length;
	char job;
	struct AllocatedSpace* next;
};
struct FreeSpace
{
	int start_address;
	int length;
	struct FreeSpace* next;
};
struct AllocatedSpace* allocated_header;
struct FreeSpace* free_header;

void allocate()
{
	char job;
	cin >> job;
	int mem;
	cin >> mem;
	FreeSpace* fs;
	for (fs = free_header; fs != NULL; fs = fs->next)
	{
		if (fs->length >= mem)
			break;
	}
	if (fs == NULL)
	{
		cout << "\t\t\t\t\t�ռ䲻�㣬�޷�����\t\t\t\t\t" << endl;
		return;
	}
	AllocatedSpace* as = new AllocatedSpace;
	as->start_address = fs->start_address;
	as->length = mem;
	as->job = job;
	as->next = NULL;
	if (allocated_header == NULL)
		allocated_header = as;
	else
	{
		AllocatedSpace* tail = allocated_header;
		while (1)
		{
			if (tail->next == NULL)
			{
				tail->next = as;
				break;
			}
			tail = tail->next;
		}
	}
	fs->length = fs->length - mem;
	fs->start_address = fs->start_address + mem;
}

void recycle()
{
	char job;
	cin >> job;
	AllocatedSpace* as = allocated_header;
	AllocatedSpace* prve = allocated_header;
	for (; as != NULL; prve = as, as = as->next) {
		if (as->job == job)
		{
			if (as == allocated_header)
				allocated_header = as->next;
			else
				prve->next = as->next;
			break;
		}
	}
	if (as == NULL)
	{
		cout << "\t\t\t\t\t�ý��̲�����\t\t\t\t\t";
		return;
	}
	FreeSpace* fs = free_header;
	FreeSpace* prve2 = free_header;
	for (; fs != NULL; prve2 = fs, fs = fs->next) {
		if (fs->start_address > as->start_address)
			break;
	}
	if (as->start_address + as->length == fs->start_address && prve2->start_address + prve2->length != as->start_address)
	{
		fs->start_address = as->start_address;
		fs->length = as->length + fs->length;
		return;
	}
	if (as->start_address + as->length != fs->start_address && prve2->start_address + prve2->length == as->start_address)
	{
		prve2->length = prve2->length + as->length;
		return;
	}
	if (as->start_address + as->length == fs->start_address && prve2->start_address + prve2->length == as->start_address)
	{
		prve2->length = prve2->length + as->length + fs->length;
		prve2->next = fs->next;
		return;
	}
	if (as->start_address + as->length != fs->start_address && prve2->start_address + prve2->length != as->start_address)
	{
		FreeSpace* newNode = new FreeSpace;
		newNode->start_address = as->start_address;
		newNode->length = as->length;
		newNode->next = fs;
		if (fs == free_header)
			free_header = newNode;
		else
			prve2->next = newNode;
		return;
	}
}
void output() {
	cout << "\t\t\t\t\t�ѷ���\t\t\t\t\t" << endl;
	for (AllocatedSpace* as = allocated_header; as != NULL; as = as->next)
		cout << "\t\t\t\t\t"<<as->job << "  " << as->start_address << "  " << as->length<<"\t\t\t\t\t" << endl;
	cout << "\t\t\t\t\t������\t\t\t\t\t" << endl;
	for (FreeSpace* fs = free_header; fs != NULL; fs = fs->next)
		cout << "\t\t\t\t\t"<<fs->start_address << "  " << fs->length <<"\t\t\t\t\t" << endl;
}
int main()
{
	free_header = new FreeSpace;
	free_header->start_address = 0;
	free_header->length = 100000;
	free_header->next = NULL;
	allocated_header = new AllocatedSpace;
	allocated_header = NULL;
	int size = 100000;
	while (1)
	{
		cout <<"\t\t\t\t\t"<<"0.�˳�" <<"\t\t\t\t\t" << endl;
		cout << "\t\t\t\t\t" << "1.�����ڴ�" << "\t\t\t\t\t" << endl;
		cout << "\t\t\t\t\t" << "2.�����ڴ�" << "\t\t\t\t\t" << endl;
		cout << "\t\t\t\t\t" << "3.�������" << "\t\t\t\t\t" << endl;
		int choice;
		int flag = 0;
		cin >> choice;
		switch (choice)
		{
		case 0:
			flag = 1;
			break;
		case 1:
			allocate();
			break;
		case 2:
			recycle();
			break;
		case 3:
			output();
			break;
		default:
			cout << "\t\t\t\t\t" << "��������ȷ��ָ��";
			break;
		}
		if (flag == 1)
			break;
	}
	cout << "\t\t\t\t\t" << "�˳�����" << "\t\t\t\t\t" << endl;
	return 0;
}